-- MySQL dump 10.13  Distrib 8.0.36, for Win64 (x86_64)
--
-- Host: 127.0.0.1    Database: pharmacylaravel
-- ------------------------------------------------------
-- Server version	9.1.0

/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!50503 SET NAMES utf8mb4 */;
/*!40103 SET @OLD_TIME_ZONE=@@TIME_ZONE */;
/*!40103 SET TIME_ZONE='+00:00' */;
/*!40014 SET @OLD_UNIQUE_CHECKS=@@UNIQUE_CHECKS, UNIQUE_CHECKS=0 */;
/*!40014 SET @OLD_FOREIGN_KEY_CHECKS=@@FOREIGN_KEY_CHECKS, FOREIGN_KEY_CHECKS=0 */;
/*!40101 SET @OLD_SQL_MODE=@@SQL_MODE, SQL_MODE='NO_AUTO_VALUE_ON_ZERO' */;
/*!40111 SET @OLD_SQL_NOTES=@@SQL_NOTES, SQL_NOTES=0 */;

--
-- Table structure for table `bar_code_data`
--

DROP TABLE IF EXISTS `bar_code_data`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `bar_code_data` (
  `id` bigint unsigned NOT NULL AUTO_INCREMENT,
  `product_name` varchar(191) CHARACTER SET utf8mb3 COLLATE utf8mb3_unicode_ci NOT NULL,
  `image` varchar(191) CHARACTER SET utf8mb3 COLLATE utf8mb3_unicode_ci DEFAULT NULL,
  `bar_code` varchar(191) CHARACTER SET utf8mb3 COLLATE utf8mb3_unicode_ci DEFAULT NULL,
  `created_at` timestamp NULL DEFAULT NULL,
  `updated_at` timestamp NULL DEFAULT NULL,
  `discount` decimal(8,2) NOT NULL DEFAULT '0.00',
  `price` decimal(8,2) DEFAULT NULL,
  `description` text CHARACTER SET utf8mb3 COLLATE utf8mb3_unicode_ci,
  `purchase_id` bigint unsigned DEFAULT NULL,
  `supplier_id` bigint unsigned DEFAULT NULL,
  `shelf` varchar(191) CHARACTER SET utf8mb3 COLLATE utf8mb3_unicode_ci DEFAULT NULL,
  `category_id` bigint unsigned DEFAULT NULL,
  `cost_price` decimal(10,2) NOT NULL DEFAULT '0.00',
  `in_stock` tinyint(1) NOT NULL DEFAULT '1',
  `stock_notified_at` timestamp NULL DEFAULT NULL,
  `pill_amount` int DEFAULT NULL,
  `price_per_pill` decimal(10,2) GENERATED ALWAYS AS (if((`pill_amount` > 0),(`cost_price` / `pill_amount`),NULL)) STORED,
  `sale_by_pill` tinyint(1) NOT NULL DEFAULT '0',
  PRIMARY KEY (`id`),
  UNIQUE KEY `bar_code_data_bar_code_unique` (`bar_code`),
  KEY `bar_code_data_purchase_id_foreign` (`purchase_id`),
  KEY `bar_code_data_supplier_id_foreign` (`supplier_id`),
  KEY `bar_code_data_category_id_foreign` (`category_id`)
) ENGINE=MyISAM AUTO_INCREMENT=26 DEFAULT CHARSET=utf8mb3 COLLATE=utf8mb3_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `bar_code_data`
--

LOCK TABLES `bar_code_data` WRITE;
/*!40000 ALTER TABLE `bar_code_data` DISABLE KEYS */;
INSERT INTO `bar_code_data` (`id`, `product_name`, `image`, `bar_code`, `created_at`, `updated_at`, `discount`, `price`, `description`, `purchase_id`, `supplier_id`, `shelf`, `category_id`, `cost_price`, `in_stock`, `stock_notified_at`, `pill_amount`, `sale_by_pill`) VALUES (4,'DOLIPRANE 1000mg 8Comp Effe/Box','1729615648_C4B96421-8C27-4EA6-91D3-B3E579325920.png','3582910075820','2024-10-22 09:47:28','2024-12-22 22:27:20',45.45,3.20,NULL,NULL,1,'A',2,2.20,1,NULL,8,0),(6,'Amoklavin-bid 625 mg x 14 film tablets','1729620475_AMOKLAVIN-625-MG-10-FILM-TAB.png','8699525093172','2024-10-22 11:07:55','2024-12-22 22:21:16',32.63,16.42,NULL,NULL,2,'C',2,12.38,1,NULL,14,0),(8,'Amoxi-Denk 1000mg (Box 10Tbl)','1729621234_5368954A-E85D-4713-85AD-C66BFD25097C.jpg',NULL,'2024-10-22 11:20:34','2024-12-22 22:26:19',45.65,6.70,NULL,NULL,2,'E',2,4.60,1,NULL,10,0),(9,'CALCIUM CORBIERE ADULT 1.1G/10ML 1x30amp = 1 box','1729621332_16231208224036941_720x@2x.png',NULL,'2024-10-22 11:22:12','2024-12-22 22:26:31',22.22,11.00,NULL,NULL,2,'D',2,9.00,1,NULL,30,0),(17,'Test Z','1733160887_860967ea5ec96498be641b75c20edb8e.jpg','12345','2024-12-02 10:34:47','2024-12-21 11:16:53',20.00,12.00,'asdasdas',NULL,1,'A',2,10.00,1,NULL,24,0),(18,'[COSRX] Advanced Snail 96 Mucin Power Essence 100ml','1733749586_thumb-7L2U7Iqk7JWM7JeR7Iqk7Yag64SI7JeQ7IS87Iqk_405x405.jpg',NULL,'2024-12-09 06:06:26','2024-12-19 07:29:04',50.00,12.00,NULL,NULL,3,NULL,3,8.00,1,NULL,NULL,0),(19,'[MEDICUBE] Collagen Jelly Cream 110ml','1733749986_collagencream1.jpg',NULL,'2024-12-09 06:13:06','2024-12-09 08:10:18',25.00,25.00,NULL,NULL,3,NULL,3,20.00,0,NULL,NULL,0),(20,'[Anua] Heartleaf 77% Soothing Toner 250ml','1733750092_thumb-anua_toner_405x405.jpg',NULL,'2024-12-09 06:14:52','2024-12-24 09:44:26',25.00,20.00,NULL,NULL,3,NULL,3,16.00,1,NULL,NULL,0),(21,'[TOCOBO] Cotton Soft Sun Stick SPF50+ PA++++','1733750468_7Yag7L2U67O07ISg7Iqk7Yux5.jpg',NULL,'2024-12-09 06:21:08','2024-12-24 09:44:26',40.00,14.00,NULL,NULL,3,NULL,3,10.00,1,NULL,NULL,0),(22,'[Beauty of Joseon] Revive Eye Serum : Ginseng + Retinal 30ml','1733750539_a.png',NULL,'2024-12-09 06:22:19','2024-12-09 07:48:51',13.33,13.60,NULL,NULL,3,NULL,3,12.00,0,NULL,NULL,0),(23,'[ROUND LAB] Birch Juice Moisturizing Sun Cream 50ml','1733750669_thumb-65287Jq065Oc656p2_405x405.jpg',NULL,'2024-12-09 06:24:29','2024-12-09 06:24:29',22.50,19.60,NULL,NULL,3,NULL,3,16.00,1,NULL,NULL,0),(24,'[SKIN1004] Madagascar Centella Air-Fit Suncream Plus 50ml','1733750707_thumb-7ISg7YGs66a8_405x405.jpg',NULL,'2024-12-09 06:25:07','2024-12-09 06:25:07',40.00,14.00,NULL,NULL,3,NULL,3,10.00,1,NULL,NULL,0),(25,'Tylenol Xs Caplets 100 Size 100s Tylenol 500 Milligram Extra Strength Pain Reliever','1734670584_81QjqQCZx4L.jpg',NULL,'2024-12-19 21:56:24','2024-12-23 12:16:55',50.00,30.00,'Tylenol Extra Strength Pain Reliever / Fever Reducer For Adults (100 Count 500 mg Caplets Per Bottle). Pack of 2 Bottles Per Quantity Ordered (200 Count Caplets Total).',NULL,2,'D',2,20.00,0,NULL,100,0);
/*!40000 ALTER TABLE `bar_code_data` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `bar_code_data_category`
--

DROP TABLE IF EXISTS `bar_code_data_category`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `bar_code_data_category` (
  `bar_code_data_id` bigint unsigned NOT NULL,
  `category_id` bigint unsigned NOT NULL,
  PRIMARY KEY (`bar_code_data_id`,`category_id`),
  KEY `bar_code_data_category_category_id_foreign` (`category_id`)
) ENGINE=MyISAM DEFAULT CHARSET=utf8mb3 COLLATE=utf8mb3_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `bar_code_data_category`
--

LOCK TABLES `bar_code_data_category` WRITE;
/*!40000 ALTER TABLE `bar_code_data_category` DISABLE KEYS */;
/*!40000 ALTER TABLE `bar_code_data_category` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `box_inventories`
--

DROP TABLE IF EXISTS `box_inventories`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `box_inventories` (
  `id` bigint unsigned NOT NULL AUTO_INCREMENT,
  `purchase_id` bigint unsigned NOT NULL,
  `remaining_pills` int NOT NULL,
  `created_at` timestamp NULL DEFAULT NULL,
  `updated_at` timestamp NULL DEFAULT NULL,
  PRIMARY KEY (`id`),
  KEY `box_inventories_purchase_id_foreign` (`purchase_id`)
) ENGINE=MyISAM DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `box_inventories`
--

LOCK TABLES `box_inventories` WRITE;
/*!40000 ALTER TABLE `box_inventories` DISABLE KEYS */;
/*!40000 ALTER TABLE `box_inventories` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `categories`
--

DROP TABLE IF EXISTS `categories`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `categories` (
  `id` bigint unsigned NOT NULL AUTO_INCREMENT,
  `name` varchar(191) CHARACTER SET utf8mb3 COLLATE utf8mb3_unicode_ci NOT NULL,
  `created_at` timestamp NULL DEFAULT NULL,
  `updated_at` timestamp NULL DEFAULT NULL,
  PRIMARY KEY (`id`)
) ENGINE=MyISAM AUTO_INCREMENT=4 DEFAULT CHARSET=utf8mb3 COLLATE=utf8mb3_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `categories`
--

LOCK TABLES `categories` WRITE;
/*!40000 ALTER TABLE `categories` DISABLE KEYS */;
INSERT INTO `categories` VALUES (1,'Test','2024-10-13 01:59:45','2024-10-13 01:59:45'),(2,'Medicine','2024-10-22 09:25:50','2024-10-22 09:25:50'),(3,'Skin Care','2024-10-22 09:26:09','2024-10-22 09:26:09');
/*!40000 ALTER TABLE `categories` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `category_product`
--

DROP TABLE IF EXISTS `category_product`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `category_product` (
  `id` bigint unsigned NOT NULL AUTO_INCREMENT,
  `product_id` bigint unsigned NOT NULL,
  `category_id` bigint unsigned NOT NULL,
  `created_at` timestamp NULL DEFAULT NULL,
  `updated_at` timestamp NULL DEFAULT NULL,
  PRIMARY KEY (`id`),
  KEY `category_product_product_id_foreign` (`product_id`),
  KEY `category_product_category_id_foreign` (`category_id`)
) ENGINE=MyISAM DEFAULT CHARSET=utf8mb3 COLLATE=utf8mb3_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `category_product`
--

LOCK TABLES `category_product` WRITE;
/*!40000 ALTER TABLE `category_product` DISABLE KEYS */;
/*!40000 ALTER TABLE `category_product` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `failed_jobs`
--

DROP TABLE IF EXISTS `failed_jobs`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `failed_jobs` (
  `id` bigint unsigned NOT NULL AUTO_INCREMENT,
  `uuid` varchar(255) CHARACTER SET utf8mb3 COLLATE utf8mb3_unicode_ci NOT NULL,
  `connection` text CHARACTER SET utf8mb3 COLLATE utf8mb3_unicode_ci NOT NULL,
  `queue` text CHARACTER SET utf8mb3 COLLATE utf8mb3_unicode_ci NOT NULL,
  `payload` longtext CHARACTER SET utf8mb3 COLLATE utf8mb3_unicode_ci NOT NULL,
  `exception` longtext CHARACTER SET utf8mb3 COLLATE utf8mb3_unicode_ci NOT NULL,
  `failed_at` timestamp NOT NULL DEFAULT CURRENT_TIMESTAMP,
  PRIMARY KEY (`id`),
  UNIQUE KEY `failed_jobs_uuid_unique` (`uuid`)
) ENGINE=MyISAM DEFAULT CHARSET=utf8mb3 COLLATE=utf8mb3_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `failed_jobs`
--

LOCK TABLES `failed_jobs` WRITE;
/*!40000 ALTER TABLE `failed_jobs` DISABLE KEYS */;
/*!40000 ALTER TABLE `failed_jobs` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `migrations`
--

DROP TABLE IF EXISTS `migrations`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `migrations` (
  `id` int unsigned NOT NULL AUTO_INCREMENT,
  `migration` varchar(255) CHARACTER SET utf8mb3 COLLATE utf8mb3_unicode_ci NOT NULL,
  `batch` int NOT NULL,
  PRIMARY KEY (`id`)
) ENGINE=MyISAM AUTO_INCREMENT=43 DEFAULT CHARSET=utf8mb3 COLLATE=utf8mb3_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `migrations`
--

LOCK TABLES `migrations` WRITE;
/*!40000 ALTER TABLE `migrations` DISABLE KEYS */;
INSERT INTO `migrations` VALUES (1,'2014_10_00_000000_create_settings_table',1),(2,'2014_10_00_000001_add_group_column_on_settings_table',1),(3,'2014_10_12_000000_create_users_table',1),(4,'2014_10_12_100000_create_password_resets_table',1),(5,'2019_08_19_000000_create_failed_jobs_table',1),(6,'2019_12_14_000001_create_personal_access_tokens_table',1),(7,'2022_02_08_163417_create_notifications_table',1),(8,'2022_02_08_164147_create_permission_tables',2),(9,'2022_02_09_140912_add_avatar_column_to_users_table',2),(10,'2022_02_09_150108_create_suppliers_table',2),(11,'2022_02_11_121758_create_categories_table',2),(12,'2022_02_11_124140_create_purchases_table',2),(13,'2022_02_17_150256_create_products_table',2),(14,'2022_02_18_153409_create_sales_table',2),(15,'2024_09_26_173611_add_product_id_to_purchases_table',3),(16,'2024_09_26_180855_create_category_product_table',4),(17,'2024_09_26_191830_add_original_quantity_to_purchases_table',5),(18,'2024_09_27_143316_create_purchase_details_table',6),(19,'2024_09_27_143317_create_purchase_details_table',7),(20,'2024_09_27_143318_create_purchase_details_table',8),(21,'2024_09_27_143319_create_purchase_details_table',9),(22,'2024_09_27_143329_create_purchase_details_table',10),(23,'2024_09_27_150228_remove_fields_from_purchase_details_table',11),(24,'2024_09_27_171508_add_invoice_no_and_date_to_purchase_details_table',12),(25,'2024_09_27_181820_create_bar_code_data_table',13),(26,'2024_10_17_093013_add_barcode_to_products_table',14),(27,'2024_10_17_093610_add_product_fields_to_bar_code_data_table',15),(28,'2024_10_17_093915_add_supplier_id_to_bar_code_data_table',16),(29,'2024_10_17_094223_add_shelf_to_bar_code_data_table',17),(30,'2024_10_18_084953_add_category_id_to_bar_code_data_table',18),(31,'2024_10_18_085955_add_fields_to_bar_code_data_table',19),(32,'2024_10_18_085956_add_fields_to_bar_code_data_table',20),(33,'2024_10_23_153902_add_purchase_id_to_sales_table',21),(34,'2024_10_30_135856_add_near_expiry_date_to_purchases_table',22),(35,'2024_10_31_162945_create_purchase_sale_table',23),(36,'2024_11_01_152433_add_in_stock_to_bar_code_data_table',24),(37,'2024_11_03_122341_create_purchase_sales_table',25),(38,'2024_11_03_151733_add_stock_notified_at_to_bar_code_data_table',26),(39,'2024_11_12_000000_add_pill_amount_to_purchases_table',27),(40,'2024_11_12_000001_add_original_pill_amount_to_purchases_table',28),(41,'2024_11_13_000000_add_sale_by_pill_to_bar_code_data_table',29),(42,'2024_12_04_000000_create_bar_code_data_category_table',30);
/*!40000 ALTER TABLE `migrations` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `model_has_permissions`
--

DROP TABLE IF EXISTS `model_has_permissions`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `model_has_permissions` (
  `permission_id` bigint unsigned NOT NULL,
  `model_type` varchar(191) CHARACTER SET utf8mb3 COLLATE utf8mb3_unicode_ci NOT NULL,
  `model_id` bigint unsigned NOT NULL,
  PRIMARY KEY (`permission_id`,`model_id`,`model_type`),
  KEY `model_has_permissions_model_id_model_type_index` (`model_id`,`model_type`)
) ENGINE=MyISAM DEFAULT CHARSET=utf8mb3 COLLATE=utf8mb3_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `model_has_permissions`
--

LOCK TABLES `model_has_permissions` WRITE;
/*!40000 ALTER TABLE `model_has_permissions` DISABLE KEYS */;
/*!40000 ALTER TABLE `model_has_permissions` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `model_has_roles`
--

DROP TABLE IF EXISTS `model_has_roles`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `model_has_roles` (
  `role_id` bigint unsigned NOT NULL,
  `model_type` varchar(191) CHARACTER SET utf8mb3 COLLATE utf8mb3_unicode_ci NOT NULL,
  `model_id` bigint unsigned NOT NULL,
  PRIMARY KEY (`role_id`,`model_id`,`model_type`),
  KEY `model_has_roles_model_id_model_type_index` (`model_id`,`model_type`)
) ENGINE=MyISAM DEFAULT CHARSET=utf8mb3 COLLATE=utf8mb3_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `model_has_roles`
--

LOCK TABLES `model_has_roles` WRITE;
/*!40000 ALTER TABLE `model_has_roles` DISABLE KEYS */;
INSERT INTO `model_has_roles` VALUES (1,'App\\Models\\User',2),(1,'App\\Models\\User',3),(2,'App\\Models\\User',1);
/*!40000 ALTER TABLE `model_has_roles` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `notifications`
--

DROP TABLE IF EXISTS `notifications`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `notifications` (
  `id` char(36) CHARACTER SET utf8mb3 COLLATE utf8mb3_unicode_ci NOT NULL,
  `type` varchar(255) CHARACTER SET utf8mb3 COLLATE utf8mb3_unicode_ci NOT NULL,
  `notifiable_type` varchar(255) CHARACTER SET utf8mb3 COLLATE utf8mb3_unicode_ci NOT NULL,
  `notifiable_id` bigint unsigned NOT NULL,
  `data` text CHARACTER SET utf8mb3 COLLATE utf8mb3_unicode_ci NOT NULL,
  `read_at` timestamp NULL DEFAULT NULL,
  `created_at` timestamp NULL DEFAULT NULL,
  `updated_at` timestamp NULL DEFAULT NULL,
  PRIMARY KEY (`id`),
  KEY `notifications_notifiable_type_notifiable_id_index` (`notifiable_type`,`notifiable_id`)
) ENGINE=MyISAM DEFAULT CHARSET=utf8mb3 COLLATE=utf8mb3_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `notifications`
--

LOCK TABLES `notifications` WRITE;
/*!40000 ALTER TABLE `notifications` DISABLE KEYS */;
INSERT INTO `notifications` VALUES ('81eb2d15-4faa-4860-8d3d-be70085625a7','App\\Notifications\\ExpiredNotification','App\\Models\\User',1,'{\"type\":\"expired\",\"product_name\":\"DOLIPRANE 1000mg 8Comp Effe\\/Box\",\"message\":\"DOLIPRANE 1000mg 8Comp Effe\\/Box has expired.\",\"image\":\"1729615648_C4B96421-8C27-4EA6-91D3-B3E579325920.png\",\"quantity\":\"20\"}','2024-11-11 09:53:26','2024-11-06 23:21:43','2024-11-11 09:53:26'),('1a1eecb2-fbfe-4c7f-85a8-f1bf88feaa94','App\\Notifications\\ExpiredNotification','App\\Models\\User',2,'{\"type\":\"expired\",\"product_name\":\"DOLIPRANE 1000mg 8Comp Effe\\/Box\",\"message\":\"DOLIPRANE 1000mg 8Comp Effe\\/Box has expired.\",\"image\":\"1729615648_C4B96421-8C27-4EA6-91D3-B3E579325920.png\",\"quantity\":\"20\"}',NULL,'2024-11-06 23:21:43','2024-11-06 23:21:43'),('54fbf6ae-8606-493b-b259-553c7180c8fb','App\\Notifications\\ExpiredNotification','App\\Models\\User',3,'{\"type\":\"expired\",\"product_name\":\"DOLIPRANE 1000mg 8Comp Effe\\/Box\",\"message\":\"DOLIPRANE 1000mg 8Comp Effe\\/Box has expired.\",\"image\":\"1729615648_C4B96421-8C27-4EA6-91D3-B3E579325920.png\",\"quantity\":\"20\"}',NULL,'2024-11-06 23:21:43','2024-11-06 23:21:43'),('09e75bd4-d393-49ea-8977-6c0a1baf32bb','App\\Notifications\\ExpiredNotification','App\\Models\\User',1,'{\"type\":\"expired\",\"product_name\":\"DOLIPRANE 1000mg 8Comp Effe\\/Box\",\"message\":\"DOLIPRANE 1000mg 8Comp Effe\\/Box has expired.\",\"image\":\"1729615648_C4B96421-8C27-4EA6-91D3-B3E579325920.png\",\"quantity\":\"20\"}','2024-11-11 09:53:26','2024-11-11 09:16:14','2024-11-11 09:53:26'),('91f06ebd-ba4b-4b55-bf8b-ff34502f5e14','App\\Notifications\\ExpiredNotification','App\\Models\\User',2,'{\"type\":\"expired\",\"product_name\":\"DOLIPRANE 1000mg 8Comp Effe\\/Box\",\"message\":\"DOLIPRANE 1000mg 8Comp Effe\\/Box has expired.\",\"image\":\"1729615648_C4B96421-8C27-4EA6-91D3-B3E579325920.png\",\"quantity\":\"20\"}',NULL,'2024-11-11 09:16:14','2024-11-11 09:16:14'),('85ad697f-27f4-4291-9906-d3383c76d85d','App\\Notifications\\ExpiredNotification','App\\Models\\User',3,'{\"type\":\"expired\",\"product_name\":\"DOLIPRANE 1000mg 8Comp Effe\\/Box\",\"message\":\"DOLIPRANE 1000mg 8Comp Effe\\/Box has expired.\",\"image\":\"1729615648_C4B96421-8C27-4EA6-91D3-B3E579325920.png\",\"quantity\":\"20\"}',NULL,'2024-11-11 09:16:14','2024-11-11 09:16:14'),('1b91bb5b-5f44-4f15-bf66-ca121c1ec236','App\\Notifications\\ExpiredNotification','App\\Models\\User',1,'{\"type\":\"expired\",\"product_name\":\"DOLIPRANE 1000mg 8Comp Effe\\/Box\",\"message\":\"DOLIPRANE 1000mg 8Comp Effe\\/Box has expired.\",\"image\":\"1729615648_C4B96421-8C27-4EA6-91D3-B3E579325920.png\",\"quantity\":\"51\"}','2024-11-11 09:53:26','2024-11-11 09:16:14','2024-11-11 09:53:26'),('a0481f52-60a6-4a39-b32f-fedde37574c5','App\\Notifications\\ExpiredNotification','App\\Models\\User',2,'{\"type\":\"expired\",\"product_name\":\"DOLIPRANE 1000mg 8Comp Effe\\/Box\",\"message\":\"DOLIPRANE 1000mg 8Comp Effe\\/Box has expired.\",\"image\":\"1729615648_C4B96421-8C27-4EA6-91D3-B3E579325920.png\",\"quantity\":\"51\"}',NULL,'2024-11-11 09:16:14','2024-11-11 09:16:14'),('fba460ff-2448-4870-8204-4a811169ad26','App\\Notifications\\ExpiredNotification','App\\Models\\User',3,'{\"type\":\"expired\",\"product_name\":\"DOLIPRANE 1000mg 8Comp Effe\\/Box\",\"message\":\"DOLIPRANE 1000mg 8Comp Effe\\/Box has expired.\",\"image\":\"1729615648_C4B96421-8C27-4EA6-91D3-B3E579325920.png\",\"quantity\":\"51\"}',NULL,'2024-11-11 09:16:14','2024-11-11 09:16:14'),('9fa135c6-3440-4d0f-a11f-3de473e3c40f','App\\Notifications\\ExpiredNotification','App\\Models\\User',1,'{\"type\":\"expired\",\"product_name\":\"Amoxi-Denk 1000mg (Box 10Tbl)\",\"message\":\"Amoxi-Denk 1000mg (Box 10Tbl) has expired.\",\"image\":\"1729621234_5368954A-E85D-4713-85AD-C66BFD25097C.jpg\",\"quantity\":\"123\"}','2024-11-11 09:53:26','2024-11-11 09:43:35','2024-11-11 09:53:26'),('4674aaff-ad7b-4abd-9d77-fca1bec12158','App\\Notifications\\ExpiredNotification','App\\Models\\User',2,'{\"type\":\"expired\",\"product_name\":\"Amoxi-Denk 1000mg (Box 10Tbl)\",\"message\":\"Amoxi-Denk 1000mg (Box 10Tbl) has expired.\",\"image\":\"1729621234_5368954A-E85D-4713-85AD-C66BFD25097C.jpg\",\"quantity\":\"123\"}',NULL,'2024-11-11 09:43:35','2024-11-11 09:43:35'),('2dd4ceb4-ec2e-4f95-a0a0-6426b236be11','App\\Notifications\\ExpiredNotification','App\\Models\\User',3,'{\"type\":\"expired\",\"product_name\":\"Amoxi-Denk 1000mg (Box 10Tbl)\",\"message\":\"Amoxi-Denk 1000mg (Box 10Tbl) has expired.\",\"image\":\"1729621234_5368954A-E85D-4713-85AD-C66BFD25097C.jpg\",\"quantity\":\"123\"}',NULL,'2024-11-11 09:43:35','2024-11-11 09:43:35'),('a6b8a29d-5328-4b15-9c2f-01bf97ec624f','App\\Notifications\\ExpiredNotification','App\\Models\\User',1,'{\"type\":\"expired\",\"product_name\":\"CALCIUM CORBIERE ADULT 1.1G\\/10ML 1x30amp = 1 box\",\"message\":\"CALCIUM CORBIERE ADULT 1.1G\\/10ML 1x30amp = 1 box has expired.\",\"image\":\"1729621332_16231208224036941_720x@2x.png\",\"quantity\":\"21\"}','2024-11-11 09:57:10','2024-11-11 09:57:04','2024-11-11 09:57:10'),('22a779eb-2fba-458f-971d-2727ef812c21','App\\Notifications\\ExpiredNotification','App\\Models\\User',2,'{\"type\":\"expired\",\"product_name\":\"CALCIUM CORBIERE ADULT 1.1G\\/10ML 1x30amp = 1 box\",\"message\":\"CALCIUM CORBIERE ADULT 1.1G\\/10ML 1x30amp = 1 box has expired.\",\"image\":\"1729621332_16231208224036941_720x@2x.png\",\"quantity\":\"21\"}',NULL,'2024-11-11 09:57:04','2024-11-11 09:57:04'),('8bdb27b9-f649-4305-9c31-7cccf6437e1a','App\\Notifications\\ExpiredNotification','App\\Models\\User',3,'{\"type\":\"expired\",\"product_name\":\"CALCIUM CORBIERE ADULT 1.1G\\/10ML 1x30amp = 1 box\",\"message\":\"CALCIUM CORBIERE ADULT 1.1G\\/10ML 1x30amp = 1 box has expired.\",\"image\":\"1729621332_16231208224036941_720x@2x.png\",\"quantity\":\"21\"}',NULL,'2024-11-11 09:57:04','2024-11-11 09:57:04'),('028367ab-d106-47a5-8ac2-9ed3c9b844f6','App\\Notifications\\ExpiredNotification','App\\Models\\User',1,'{\"type\":\"expired\",\"product_name\":\"Amoklavin-bid 625 mg x 14 film tablets\",\"message\":\"Amoklavin-bid 625 mg x 14 film tablets has expired.\",\"image\":\"1729620475_AMOKLAVIN-625-MG-10-FILM-TAB.png\",\"quantity\":\"212\"}','2024-11-11 10:04:17','2024-11-11 09:58:57','2024-11-11 10:04:17'),('16e1692f-5136-4353-bc49-ce61ac9a1620','App\\Notifications\\ExpiredNotification','App\\Models\\User',2,'{\"type\":\"expired\",\"product_name\":\"Amoklavin-bid 625 mg x 14 film tablets\",\"message\":\"Amoklavin-bid 625 mg x 14 film tablets has expired.\",\"image\":\"1729620475_AMOKLAVIN-625-MG-10-FILM-TAB.png\",\"quantity\":\"212\"}',NULL,'2024-11-11 09:58:57','2024-11-11 09:58:57'),('a528c6e5-8583-4cd4-a696-4eb53018b8e2','App\\Notifications\\ExpiredNotification','App\\Models\\User',3,'{\"type\":\"expired\",\"product_name\":\"Amoklavin-bid 625 mg x 14 film tablets\",\"message\":\"Amoklavin-bid 625 mg x 14 film tablets has expired.\",\"image\":\"1729620475_AMOKLAVIN-625-MG-10-FILM-TAB.png\",\"quantity\":\"212\"}',NULL,'2024-11-11 09:58:57','2024-11-11 09:58:57'),('a35150f6-5fc3-4219-8a5e-86e20678922e','App\\Notifications\\ExpiredNotification','App\\Models\\User',3,'{\"type\":\"expired\",\"purchase_id\":9,\"product_name\":\"CALCIUM CORBIERE ADULT 1.1G\\/10ML 1x30amp = 1 box\",\"message\":\"CALCIUM CORBIERE ADULT 1.1G\\/10ML 1x30amp = 1 box has expired.\",\"image\":\"1729621332_16231208224036941_720x@2x.png\",\"quantity\":10}',NULL,'2024-12-23 00:27:44','2024-12-23 00:27:44'),('abc5825e-bdc8-4879-999e-8f4e38c662ae','App\\Notifications\\ExpiredNotification','App\\Models\\User',1,'{\"type\":\"expired\",\"purchase_id\":9,\"product_name\":\"CALCIUM CORBIERE ADULT 1.1G\\/10ML 1x30amp = 1 box\",\"message\":\"CALCIUM CORBIERE ADULT 1.1G\\/10ML 1x30amp = 1 box has expired.\",\"image\":\"1729621332_16231208224036941_720x@2x.png\",\"quantity\":10}',NULL,'2024-12-23 00:27:44','2024-12-23 00:27:44'),('a197017a-865f-4471-a622-6bf5d0a40e21','App\\Notifications\\ExpiredNotification','App\\Models\\User',2,'{\"type\":\"expired\",\"purchase_id\":9,\"product_name\":\"CALCIUM CORBIERE ADULT 1.1G\\/10ML 1x30amp = 1 box\",\"message\":\"CALCIUM CORBIERE ADULT 1.1G\\/10ML 1x30amp = 1 box has expired.\",\"image\":\"1729621332_16231208224036941_720x@2x.png\",\"quantity\":10}',NULL,'2024-12-23 00:27:44','2024-12-23 00:27:44'),('00d95439-d020-4b95-ac3e-834c5d466e8d','App\\Notifications\\LowStockNotification','App\\Models\\User',1,'{\"product_name\":\"Randy\",\"quantity\":2,\"message\":\"Randy is low on stock. Only 2 left.\",\"image\":null}','2024-12-04 20:03:00','2024-11-19 08:21:01','2024-12-04 20:03:00'),('1e0a1ebf-df22-4e66-ab99-08c328b032fc','App\\Notifications\\LowStockNotification','App\\Models\\User',1,'{\"product_name\":\"test\",\"quantity\":5,\"message\":\"test is low on stock. Only 5 left.\",\"image\":null}','2024-12-04 20:03:00','2024-11-19 08:06:20','2024-12-04 20:03:00'),('f7115cab-d906-4c63-a1c6-e90ac0c3d944','App\\Notifications\\LowStockNotification','App\\Models\\User',1,'{\"product_name\":\"test\",\"quantity\":3,\"message\":\"test is low on stock. Only 3 left.\",\"image\":null}','2024-12-04 20:03:00','2024-11-19 08:21:01','2024-12-04 20:03:00'),('8ddd0fd0-2ee5-4ba4-acaf-da68002ee89d','App\\Notifications\\LowStockNotification','App\\Models\\User',1,'{\"product_name\":\"test\",\"quantity\":5,\"message\":\"test is low on stock. Only 5 left.\",\"image\":null}','2024-12-04 20:03:00','2024-11-18 09:03:48','2024-12-04 20:03:00'),('fe7278f1-c463-4de8-baea-33065e80f03b','App\\Notifications\\LowStockNotification','App\\Models\\User',1,'{\"product_name\":\"Randy\",\"quantity\":5,\"message\":\"Randy is low on stock. Only 5 left.\",\"image\":null}','2024-12-04 20:03:00','2024-11-19 02:20:12','2024-12-04 20:03:00'),('8c38ed85-5f64-453b-95bc-82944cf097a0','App\\Notifications\\LowStockNotification','App\\Models\\User',1,'{\"product_name\":\"Randy\",\"quantity\":5,\"message\":\"Randy is low on stock. Only 5 left.\",\"image\":null}','2024-12-04 20:03:00','2024-11-19 02:26:55','2024-12-04 20:03:00'),('50d64aab-e3ef-4762-b8e7-fe208a3ad42e','App\\Notifications\\LowStockNotification','App\\Models\\User',1,'{\"product_name\":\"test\",\"quantity\":5,\"message\":\"test is low on stock. Only 5 left.\",\"image\":null}','2024-12-04 20:03:00','2024-11-19 05:47:52','2024-12-04 20:03:00'),('00686635-19fe-4407-b4c8-9aa82c0c77ec','App\\Notifications\\LowStockNotification','App\\Models\\User',1,'{\"product_name\":\"test\",\"quantity\":3,\"message\":\"test is low on stock. Only 3 left.\",\"image\":null}','2024-12-04 20:03:00','2024-11-19 06:14:02','2024-12-04 20:03:00'),('557c2b57-61c9-458c-95fe-c0cc14e189eb','App\\Notifications\\LowStockNotification','App\\Models\\User',1,'{\"product_name\":\"test\",\"quantity\":5,\"message\":\"test is low on stock. Only 5 left.\",\"image\":null}','2024-12-04 20:03:00','2024-11-19 06:41:42','2024-12-04 20:03:00'),('65171a1a-d898-4311-b755-5449531e3734','App\\Notifications\\LowStockNotification','App\\Models\\User',1,'{\"product_name\":\"Randy\",\"quantity\":2,\"message\":\"Randy is low on stock. Only 2 left.\",\"image\":null}','2024-12-04 20:03:00','2024-11-19 08:21:17','2024-12-04 20:03:00'),('bcf63455-db25-4d77-b55a-ddb95b457d60','App\\Notifications\\LowStockNotification','App\\Models\\User',1,'{\"product_name\":\"Randy\",\"quantity\":2,\"message\":\"Randy is low on stock. Only 2 left.\",\"image\":null}','2024-12-04 20:03:00','2024-11-19 08:21:52','2024-12-04 20:03:00'),('210bba7d-f80a-4d5f-b037-31a2cb258a62','App\\Notifications\\LowStockNotification','App\\Models\\User',1,'{\"product_name\":\"test\",\"quantity\":4,\"message\":\"test is low on stock. Only 4 left.\",\"image\":null}','2024-12-04 20:03:00','2024-11-18 08:39:52','2024-12-04 20:03:00'),('646dd5c8-4324-4256-9299-235e0e85343c','App\\Notifications\\LowStockNotification','App\\Models\\User',1,'{\"product_name\":\"test\",\"quantity\":5,\"message\":\"test is low on stock. Only 5 left.\",\"image\":null}','2024-12-04 20:03:00','2024-11-18 08:31:43','2024-12-04 20:03:00'),('2931804e-f936-4d9a-a626-68dbe8613344','App\\Notifications\\LowStockNotification','App\\Models\\User',1,'{\"product_name\":\"test\",\"quantity\":4,\"message\":\"test is low on stock. Only 4 left.\",\"image\":null}','2024-12-04 20:03:00','2024-11-18 08:31:48','2024-12-04 20:03:00'),('3dfd7bbb-1688-4ed0-9401-e8404159b78e','App\\Notifications\\LowStockNotification','App\\Models\\User',1,'{\"product_name\":\"test\",\"quantity\":2,\"message\":\"test is low on stock. Only 2 left.\",\"image\":null}','2024-12-04 20:03:00','2024-11-19 08:28:43','2024-12-04 20:03:00'),('acbb9601-9a0a-454a-b456-79123f23f8be','App\\Notifications\\LowStockNotification','App\\Models\\User',1,'{\"product_name\":\"test\",\"quantity\":2,\"message\":\"test is low on stock. Only 2 left.\",\"image\":null}','2024-12-04 20:03:00','2024-11-19 08:29:04','2024-12-04 20:03:00'),('6e1da937-3010-4ef8-9358-8bcbab31ed01','App\\Notifications\\LowStockNotification','App\\Models\\User',1,'{\"product_name\":\"test\",\"quantity\":1,\"message\":\"test is low on stock. Only 1 left.\",\"image\":null}','2024-12-04 20:03:00','2024-11-19 08:29:24','2024-12-04 20:03:00'),('4a23e3cf-c230-49d9-809f-84f22323ef3e','App\\Notifications\\LowStockNotification','App\\Models\\User',1,'{\"product_name\":\"test\",\"quantity\":1,\"message\":\"test is low on stock. Only 1 left.\",\"image\":null}','2024-12-04 20:03:00','2024-11-19 08:29:59','2024-12-04 20:03:00'),('86860724-a7f2-4882-9783-c7775422b0d4','App\\Notifications\\LowStockNotification','App\\Models\\User',1,'{\"product_name\":\"test\",\"quantity\":0,\"message\":\"test is low on stock. Only 0 left.\",\"image\":null}','2024-12-04 20:03:00','2024-11-19 08:31:11','2024-12-04 20:03:00'),('a7fa8c13-d521-4cd0-9853-cb90e5a7851c','App\\Notifications\\LowStockNotification','App\\Models\\User',1,'{\"product_name\":\"test\",\"quantity\":2,\"message\":\"test is low on stock. Only 2 left.\",\"image\":null}','2024-12-04 20:03:00','2024-11-19 08:37:14','2024-12-04 20:03:00'),('a5f70a85-1e88-493f-8caa-d67d4de004b8','App\\Notifications\\LowStockNotification','App\\Models\\User',1,'{\"product_name\":\"test\",\"quantity\":1,\"message\":\"test is low on stock. Only 1 left.\",\"image\":null}','2024-12-04 20:03:00','2024-11-19 08:37:38','2024-12-04 20:03:00'),('a3498885-6531-4499-aae8-261e6a4f3306','App\\Notifications\\LowStockNotification','App\\Models\\User',1,'{\"product_name\":\"test\",\"quantity\":1,\"message\":\"test is low on stock. Only 1 left.\",\"image\":null}','2024-12-04 20:03:00','2024-11-19 08:38:01','2024-12-04 20:03:00'),('82499da6-7d56-4091-abff-23e589c7b4bf','App\\Notifications\\LowStockNotification','App\\Models\\User',1,'{\"product_name\":\"test\",\"quantity\":1,\"message\":\"test is low on stock. Only 1 left.\",\"image\":null}','2024-12-04 20:03:00','2024-11-19 08:38:22','2024-12-04 20:03:00'),('03b8e56b-b9ca-4b0b-878b-69c059078224','App\\Notifications\\LowStockNotification','App\\Models\\User',1,'{\"product_name\":\"test\",\"quantity\":1,\"message\":\"test is low on stock. Only 1 left.\",\"image\":null}','2024-12-04 20:03:00','2024-11-19 08:43:09','2024-12-04 20:03:00'),('7a0cf684-6918-4c43-b75a-4a1a1c956521','App\\Notifications\\LowStockNotification','App\\Models\\User',1,'{\"product_name\":\"test\",\"quantity\":0,\"message\":\"test is low on stock. Only 0 left.\",\"image\":null}','2024-12-04 20:03:00','2024-11-19 08:43:31','2024-12-04 20:03:00'),('4936cb04-8343-4a54-a57c-eb080c02f7b6','App\\Notifications\\LowStockNotification','App\\Models\\User',1,'{\"product_name\":\"test\",\"quantity\":2,\"message\":\"test is low on stock. Only 2 left.\",\"image\":null}','2024-12-04 20:03:00','2024-11-19 08:49:04','2024-12-04 20:03:00'),('f47bc96a-85a3-4c9c-b1e1-637cbc66987c','App\\Notifications\\LowStockNotification','App\\Models\\User',1,'{\"product_name\":\"test\",\"quantity\":1,\"message\":\"test is low on stock. Only 1 left.\",\"image\":null}','2024-12-04 20:03:00','2024-11-19 08:53:00','2024-12-04 20:03:00'),('7664e800-021e-402e-bf78-0b48d4ef49b8','App\\Notifications\\LowStockNotification','App\\Models\\User',1,'{\"product_name\":\"Test Z\",\"quantity\":5,\"message\":\"Test Z is low on stock. Only 5 left.\",\"image\":\"1733160887_860967ea5ec96498be641b75c20edb8e.jpg\"}','2024-12-03 06:56:01','2024-12-03 01:00:30','2024-12-03 06:56:01'),('6a55e04d-7e8c-4427-af88-d81ce5767920','App\\Notifications\\LowStockNotification','App\\Models\\User',1,'{\"type\":\"low_stock\",\"product_name\":\"test\",\"quantity\":2,\"message\":\"test is low on stock. Only 2 left.\",\"image\":null}','2024-12-04 20:03:00','2024-12-03 06:58:05','2024-12-04 20:03:00'),('93b41dd8-ea09-4703-a07e-de7eab9bf922','App\\Notifications\\LowStockNotification','App\\Models\\User',1,'{\"type\":\"low_stock\",\"product_name\":\"[COSRX] Advanced Snail 96 Mucin Power Essence 100ml\",\"quantity\":0,\"message\":\"[COSRX] Advanced Snail 96 Mucin Power Essence 100ml is low on stock. Only 0 left.\",\"image\":\"1733749586_thumb-7L2U7Iqk7JWM7JeR7Iqk7Yag64SI7JeQ7IS87Iqk_405x405.jpg\"}','2024-12-09 07:48:19','2024-12-09 07:06:41','2024-12-09 07:48:19'),('731efcc8-e86f-4e50-822c-087f4aed3e00','App\\Notifications\\LowStockNotification','App\\Models\\User',1,'{\"type\":\"low_stock\",\"product_name\":\"[COSRX] Advanced Snail 96 Mucin Power Essence 100ml\",\"quantity\":0,\"message\":\"[COSRX] Advanced Snail 96 Mucin Power Essence 100ml is low on stock. Only 0 left.\",\"image\":\"1733749586_thumb-7L2U7Iqk7JWM7JeR7Iqk7Yag64SI7JeQ7IS87Iqk_405x405.jpg\"}','2024-12-09 07:48:19','2024-12-09 07:36:52','2024-12-09 07:48:19'),('d21c84e1-631c-431d-8e77-fd67ad2389e3','App\\Notifications\\LowStockNotification','App\\Models\\User',1,'{\"type\":\"low_stock\",\"product_name\":\"[COSRX] Advanced Snail 96 Mucin Power Essence 100ml\",\"quantity\":0,\"message\":\"[COSRX] Advanced Snail 96 Mucin Power Essence 100ml is low on stock. Only 0 left.\",\"image\":\"1733749586_thumb-7L2U7Iqk7JWM7JeR7Iqk7Yag64SI7JeQ7IS87Iqk_405x405.jpg\"}','2024-12-09 07:48:19','2024-12-09 07:38:44','2024-12-09 07:48:19'),('9e131a51-e2a8-41c7-a4b1-011a19e150df','App\\Notifications\\LowStockNotification','App\\Models\\User',1,'{\"type\":\"low_stock\",\"product_name\":\"[Anua] Heartleaf 77% Soothing Toner 250ml\",\"quantity\":0,\"message\":\"[Anua] Heartleaf 77% Soothing Toner 250ml is low on stock. Only 0 left.\",\"image\":\"1733750092_thumb-anua_toner_405x405.jpg\"}','2024-12-20 08:38:05','2024-12-09 07:48:51','2024-12-20 08:38:05'),('33a9f413-83aa-4ff8-baa9-77becf68c3d6','App\\Notifications\\LowStockNotification','App\\Models\\User',1,'{\"type\":\"low_stock\",\"product_name\":\"[TOCOBO] Cotton Soft Sun Stick SPF50+ PA++++\",\"quantity\":0,\"message\":\"[TOCOBO] Cotton Soft Sun Stick SPF50+ PA++++ is low on stock. Only 0 left.\",\"image\":\"1733750468_7Yag7L2U67O07ISg7Iqk7Yux5.jpg\"}','2024-12-20 08:38:05','2024-12-09 07:48:51','2024-12-20 08:38:05'),('e7cb53d0-1871-45cc-a6f8-3a982f52ca16','App\\Notifications\\LowStockNotification','App\\Models\\User',1,'{\"type\":\"low_stock\",\"product_name\":\"[Beauty of Joseon] Revive Eye Serum : Ginseng + Retinal 30ml\",\"quantity\":0,\"message\":\"[Beauty of Joseon] Revive Eye Serum : Ginseng + Retinal 30ml is low on stock. Only 0 left.\",\"image\":\"1733750539_a.png\"}','2024-12-20 08:38:05','2024-12-09 07:48:51','2024-12-20 08:38:05'),('d25d3d1d-895d-4db0-8175-69783a178163','App\\Notifications\\LowStockNotification','App\\Models\\User',1,'{\"type\":\"low_stock\",\"product_name\":\"[MEDICUBE] Collagen Jelly Cream 110ml\",\"quantity\":0,\"message\":\"[MEDICUBE] Collagen Jelly Cream 110ml is low on stock. Only 0 left.\",\"image\":\"1733749986_collagencream1.jpg\"}','2024-12-20 08:38:05','2024-12-09 08:10:18','2024-12-20 08:38:05'),('e040320e-07f8-4bd6-baf5-46173f758643','App\\Notifications\\LowStockNotification','App\\Models\\User',1,'{\"type\":\"low_stock\",\"product_name\":\"[COSRX] Advanced Snail 96 Mucin Power Essence 100ml\",\"quantity\":4,\"message\":\"[COSRX] Advanced Snail 96 Mucin Power Essence 100ml is low on stock. Only 4 left.\",\"image\":\"1733749586_thumb-7L2U7Iqk7JWM7JeR7Iqk7Yag64SI7JeQ7IS87Iqk_405x405.jpg\"}','2024-12-20 08:38:05','2024-12-19 07:42:06','2024-12-20 08:38:05'),('a8ee9e38-b0cc-4622-a075-73f11a985c0e','App\\Notifications\\LowStockNotification','App\\Models\\User',1,'{\"type\":\"low_stock\",\"product_name\":\"[COSRX] Advanced Snail 96 Mucin Power Essence 100ml\",\"quantity\":3,\"message\":\"[COSRX] Advanced Snail 96 Mucin Power Essence 100ml is low on stock. Only 3 left.\",\"image\":\"1733749586_thumb-7L2U7Iqk7JWM7JeR7Iqk7Yag64SI7JeQ7IS87Iqk_405x405.jpg\"}','2024-12-20 08:38:05','2024-12-19 08:09:53','2024-12-20 08:38:05'),('8e03c401-6192-46b2-ac67-5af5149af2a1','App\\Notifications\\LowStockNotification','App\\Models\\User',1,'{\"type\":\"low_stock\",\"product_name\":\"Tylenol Xs Caplets 100 Size 100s Tylenol 500 Milligram Extra Strength Pain Reliever\",\"quantity\":4,\"message\":\"Tylenol Xs Caplets 100 Size 100s Tylenol 500 Milligram Extra Strength Pain Reliever is low on stock. Only 4 left.\",\"image\":\"1734670584_81QjqQCZx4L.jpg\"}','2024-12-20 08:38:05','2024-12-19 22:21:47','2024-12-20 08:38:05'),('bb2c2562-b5dc-41e2-91c4-4ae8472504fe','App\\Notifications\\LowStockNotification','App\\Models\\User',1,'{\"type\":\"low_stock\",\"product_name\":\"Test Z\",\"quantity\":5,\"message\":\"Test Z is low on stock. Only 5 left.\",\"image\":\"1733160887_860967ea5ec96498be641b75c20edb8e.jpg\"}','2024-12-20 08:38:05','2024-12-20 02:10:02','2024-12-20 08:38:05'),('0958e730-94dd-4dbc-b2c9-db39af5cf4e3','App\\Notifications\\LowStockNotification','App\\Models\\User',1,'{\"type\":\"low_stock\",\"product_name\":\"Test Z\",\"quantity\":1,\"message\":\"Test Z is low on stock. Only 1 left.\",\"image\":\"1733160887_860967ea5ec96498be641b75c20edb8e.jpg\"}','2024-12-22 21:44:28','2024-12-21 10:31:27','2024-12-22 21:44:28'),('3c769317-9e7e-4cb7-bc34-6dcfbc335910','App\\Notifications\\LowStockNotification','App\\Models\\User',1,'{\"type\":\"low_stock\",\"product_name\":\"Test Z\",\"quantity\":0,\"message\":\"Test Z is low on stock. Only 0 left.\",\"image\":\"1733160887_860967ea5ec96498be641b75c20edb8e.jpg\"}','2024-12-22 21:44:28','2024-12-21 10:51:59','2024-12-22 21:44:28'),('5f05b2a3-cf4d-4951-a388-a9d6deb4798b','App\\Notifications\\LowStockNotification','App\\Models\\User',1,'{\"type\":\"low_stock\",\"product_name\":\"Test Z\",\"quantity\":5,\"message\":\"Test Z is low on stock. Only 5 left.\",\"image\":\"1733160887_860967ea5ec96498be641b75c20edb8e.jpg\"}','2024-12-22 21:44:28','2024-12-21 10:52:50','2024-12-22 21:44:28'),('4c6f1d04-0d72-4d7f-a0d9-06c4080cca1b','App\\Notifications\\LowStockNotification','App\\Models\\User',1,'{\"type\":\"low_stock\",\"product_name\":\"Test Z\",\"quantity\":4,\"message\":\"Test Z is low on stock. Only 4 left.\",\"image\":\"1733160887_860967ea5ec96498be641b75c20edb8e.jpg\"}','2024-12-22 21:44:28','2024-12-21 10:53:30','2024-12-22 21:44:28'),('8c85137c-ce48-47cb-b84d-a065e2a3bee4','App\\Notifications\\LowStockNotification','App\\Models\\User',1,'{\"type\":\"low_stock\",\"product_name\":\"Test Z\",\"quantity\":3,\"message\":\"Test Z is low on stock. Only 3 left.\",\"image\":\"1733160887_860967ea5ec96498be641b75c20edb8e.jpg\"}','2024-12-22 21:44:28','2024-12-21 10:55:56','2024-12-22 21:44:28'),('e1780072-ab63-4c31-bc86-ad46b6ff2060','App\\Notifications\\LowStockNotification','App\\Models\\User',1,'{\"type\":\"low_stock\",\"product_name\":\"Test Z\",\"quantity\":2,\"message\":\"Test Z is low on stock. Only 2 left.\",\"image\":\"1733160887_860967ea5ec96498be641b75c20edb8e.jpg\"}','2024-12-22 21:44:28','2024-12-21 10:56:11','2024-12-22 21:44:28'),('d528dff5-0b11-4ab2-a070-b1ba5d89deea','App\\Notifications\\LowStockNotification','App\\Models\\User',1,'{\"type\":\"low_stock\",\"product_name\":\"Test Z\",\"quantity\":1,\"message\":\"Test Z is low on stock. Only 1 left.\",\"image\":\"1733160887_860967ea5ec96498be641b75c20edb8e.jpg\"}','2024-12-22 21:44:28','2024-12-21 10:57:09','2024-12-22 21:44:28'),('69bc3728-15e1-4710-aede-c7c7e4f7b944','App\\Notifications\\LowStockNotification','App\\Models\\User',1,'{\"type\":\"low_stock\",\"product_name\":\"Test Z\",\"quantity\":0,\"message\":\"Test Z is low on stock. Only 0 left.\",\"image\":\"1733160887_860967ea5ec96498be641b75c20edb8e.jpg\"}','2024-12-22 21:44:28','2024-12-21 11:06:35','2024-12-22 21:44:28'),('d135b545-d580-4f72-be49-fb277de53fd0','App\\Notifications\\LowStockNotification','App\\Models\\User',1,'{\"type\":\"low_stock\",\"product_name\":\"DOLIPRANE 1000mg 8Comp Effe\\/Box\",\"quantity\":4,\"message\":\"DOLIPRANE 1000mg 8Comp Effe\\/Box is low on stock. Only 4 left.\",\"image\":\"1729615648_C4B96421-8C27-4EA6-91D3-B3E579325920.png\"}',NULL,'2024-12-22 22:29:09','2024-12-22 22:29:09'),('6ea56a38-b20e-478f-a2a8-42efcc7f99e9','App\\Notifications\\LowStockNotification','App\\Models\\User',1,'{\"type\":\"low_stock\",\"product_name\":\"Amoklavin-bid 625 mg x 14 film tablets\",\"quantity\":4,\"message\":\"Amoklavin-bid 625 mg x 14 film tablets is low on stock. Only 4 left.\",\"image\":\"1729620475_AMOKLAVIN-625-MG-10-FILM-TAB.png\"}',NULL,'2024-12-22 23:33:07','2024-12-22 23:33:07'),('f27676fb-7dd3-4d2c-a286-c8291addd64d','App\\Notifications\\ExpiredNotification','App\\Models\\User',3,'{\"type\":\"expired\",\"purchase_id\":4,\"product_name\":\"Amoklavin-bid 625 mg x 14 film tablets\",\"message\":\"Amoklavin-bid 625 mg x 14 film tablets has expired.\",\"image\":\"1729620475_AMOKLAVIN-625-MG-10-FILM-TAB.png\",\"quantity\":4}',NULL,'2024-12-23 00:27:44','2024-12-23 00:27:44'),('2ff6f326-2816-4965-b40e-2e75da758f3a','App\\Notifications\\ExpiredNotification','App\\Models\\User',2,'{\"type\":\"expired\",\"purchase_id\":4,\"product_name\":\"Amoklavin-bid 625 mg x 14 film tablets\",\"message\":\"Amoklavin-bid 625 mg x 14 film tablets has expired.\",\"image\":\"1729620475_AMOKLAVIN-625-MG-10-FILM-TAB.png\",\"quantity\":4}',NULL,'2024-12-23 00:27:44','2024-12-23 00:27:44'),('1cd3b1b6-07b8-425b-8877-17c655508048','App\\Notifications\\ExpiredNotification','App\\Models\\User',1,'{\"type\":\"expired\",\"purchase_id\":4,\"product_name\":\"Amoklavin-bid 625 mg x 14 film tablets\",\"message\":\"Amoklavin-bid 625 mg x 14 film tablets has expired.\",\"image\":\"1729620475_AMOKLAVIN-625-MG-10-FILM-TAB.png\",\"quantity\":4}',NULL,'2024-12-23 00:27:44','2024-12-23 00:27:44'),('6a9ac6f3-92ee-45d2-a778-145f635a206d','App\\Notifications\\LowStockNotification','App\\Models\\User',1,'{\"type\":\"low_stock\",\"product_name\":\"Test Z\",\"quantity\":5,\"message\":\"Test Z is low on stock. Only 5 left.\",\"image\":\"1733160887_860967ea5ec96498be641b75c20edb8e.jpg\"}',NULL,'2024-12-22 23:44:34','2024-12-22 23:44:34'),('c8ecdfbd-52de-4a2b-80b7-039426ff93a6','App\\Notifications\\NearlyExpiredNotification','App\\Models\\User',3,'{\"type\":\"nearly_expired\",\"purchase_id\":8,\"product_name\":\"Amoxi-Denk 1000mg (Box 10Tbl)\",\"message\":\"Amoxi-Denk 1000mg (Box 10Tbl) is nearly expired.\",\"image\":\"1729621234_5368954A-E85D-4713-85AD-C66BFD25097C.jpg\",\"quantity\":7}',NULL,'2024-12-23 00:17:13','2024-12-23 00:17:13'),('05a13317-7382-4424-9071-1b073d863564','App\\Notifications\\NearlyExpiredNotification','App\\Models\\User',2,'{\"type\":\"nearly_expired\",\"purchase_id\":8,\"product_name\":\"Amoxi-Denk 1000mg (Box 10Tbl)\",\"message\":\"Amoxi-Denk 1000mg (Box 10Tbl) is nearly expired.\",\"image\":\"1729621234_5368954A-E85D-4713-85AD-C66BFD25097C.jpg\",\"quantity\":7}',NULL,'2024-12-23 00:17:13','2024-12-23 00:17:13'),('1a08351b-f69b-4f69-af0b-612e00f75430','App\\Notifications\\NearlyExpiredNotification','App\\Models\\User',1,'{\"type\":\"nearly_expired\",\"purchase_id\":8,\"product_name\":\"Amoxi-Denk 1000mg (Box 10Tbl)\",\"message\":\"Amoxi-Denk 1000mg (Box 10Tbl) is nearly expired.\",\"image\":\"1729621234_5368954A-E85D-4713-85AD-C66BFD25097C.jpg\",\"quantity\":7}',NULL,'2024-12-23 00:17:13','2024-12-23 00:17:13'),('f7be543c-a0c1-4d5c-9499-900b75ca70ff','App\\Notifications\\LowStockNotification','App\\Models\\User',1,'{\"type\":\"low_stock\",\"product_name\":\"Tylenol Xs Caplets 100 Size 100s Tylenol 500 Milligram Extra Strength Pain Reliever\",\"quantity\":5,\"message\":\"Tylenol Xs Caplets 100 Size 100s Tylenol 500 Milligram Extra Strength Pain Reliever is low on stock. Only 5 left.\",\"image\":\"1734670584_81QjqQCZx4L.jpg\"}',NULL,'2024-12-23 11:40:47','2024-12-23 11:40:47'),('39c00829-7a7d-4d68-bb91-ebd6edc466d1','App\\Notifications\\LowStockNotification','App\\Models\\User',1,'{\"type\":\"low_stock\",\"product_name\":\"Tylenol Xs Caplets 100 Size 100s Tylenol 500 Milligram Extra Strength Pain Reliever\",\"quantity\":3,\"message\":\"Tylenol Xs Caplets 100 Size 100s Tylenol 500 Milligram Extra Strength Pain Reliever is low on stock. Only 3 left.\",\"image\":\"1734670584_81QjqQCZx4L.jpg\"}',NULL,'2024-12-23 12:08:23','2024-12-23 12:08:23'),('22978e57-0ea2-4d9a-a875-36b4f5ffa683','App\\Notifications\\LowStockNotification','App\\Models\\User',1,'{\"type\":\"low_stock\",\"product_name\":\"Tylenol Xs Caplets 100 Size 100s Tylenol 500 Milligram Extra Strength Pain Reliever\",\"quantity\":1,\"message\":\"Tylenol Xs Caplets 100 Size 100s Tylenol 500 Milligram Extra Strength Pain Reliever is low on stock. Only 1 left.\",\"image\":\"1734670584_81QjqQCZx4L.jpg\"}',NULL,'2024-12-23 12:09:13','2024-12-23 12:09:13'),('ac22880d-4076-425e-9560-18c84eaffcef','App\\Notifications\\LowStockNotification','App\\Models\\User',1,'{\"type\":\"low_stock\",\"product_name\":\"Tylenol Xs Caplets 100 Size 100s Tylenol 500 Milligram Extra Strength Pain Reliever\",\"quantity\":0,\"message\":\"Tylenol Xs Caplets 100 Size 100s Tylenol 500 Milligram Extra Strength Pain Reliever is low on stock. Only 0 left.\",\"image\":\"1734670584_81QjqQCZx4L.jpg\"}',NULL,'2024-12-23 12:16:55','2024-12-23 12:16:55'),('4ecdf3cd-402e-40f4-993a-d2ce695c62ec','App\\Notifications\\LowStockNotification','App\\Models\\User',1,'{\"type\":\"low_stock\",\"product_name\":\"Amoxi-Denk 1000mg (Box 10Tbl)\",\"quantity\":5,\"message\":\"Amoxi-Denk 1000mg (Box 10Tbl) is low on stock. Only 5 left.\",\"image\":\"1729621234_5368954A-E85D-4713-85AD-C66BFD25097C.jpg\"}',NULL,'2024-12-23 12:41:46','2024-12-23 12:41:46'),('63cdba6c-d63c-4c21-8bda-c4a594dc16d7','App\\Notifications\\LowStockNotification','App\\Models\\User',1,'{\"type\":\"low_stock\",\"product_name\":\"Test Z\",\"quantity\":4,\"message\":\"Test Z is low on stock. Only 4 left.\",\"image\":\"1733160887_860967ea5ec96498be641b75c20edb8e.jpg\"}',NULL,'2024-12-23 20:54:22','2024-12-23 20:54:22'),('1abee002-e480-49e7-be2c-82ed174080b9','App\\Notifications\\LowStockNotification','App\\Models\\User',1,'{\"type\":\"low_stock\",\"product_name\":\"Test Z\",\"quantity\":3,\"message\":\"Test Z is low on stock. Only 3 left.\",\"image\":\"1733160887_860967ea5ec96498be641b75c20edb8e.jpg\"}',NULL,'2024-12-23 20:57:17','2024-12-23 20:57:17'),('12b5741e-26b7-44da-9bcb-5b902319d92e','App\\Notifications\\LowStockNotification','App\\Models\\User',1,'{\"type\":\"low_stock\",\"product_name\":\"Test Z\",\"quantity\":2,\"message\":\"Test Z is low on stock. Only 2 left.\",\"image\":\"1733160887_860967ea5ec96498be641b75c20edb8e.jpg\"}',NULL,'2024-12-23 20:59:56','2024-12-23 20:59:56'),('ed7c2110-bedd-4b6b-941c-a6b5e4652144','App\\Notifications\\LowStockNotification','App\\Models\\User',1,'{\"type\":\"low_stock\",\"product_name\":\"Amoxi-Denk 1000mg (Box 10Tbl)\",\"quantity\":4,\"message\":\"Amoxi-Denk 1000mg (Box 10Tbl) is low on stock. Only 4 left.\",\"image\":\"1729621234_5368954A-E85D-4713-85AD-C66BFD25097C.jpg\"}',NULL,'2024-12-23 21:00:50','2024-12-23 21:00:50'),('5387c4b4-38b4-40be-93a6-8d1809d5bb86','App\\Notifications\\LowStockNotification','App\\Models\\User',1,'{\"type\":\"low_stock\",\"product_name\":\"Test Z\",\"quantity\":1,\"message\":\"Test Z is low on stock. Only 1 left.\",\"image\":\"1733160887_860967ea5ec96498be641b75c20edb8e.jpg\"}',NULL,'2024-12-23 21:14:28','2024-12-23 21:14:28'),('19c20223-56da-49f0-bcef-3be48648df3f','App\\Notifications\\LowStockNotification','App\\Models\\User',1,'{\"type\":\"low_stock\",\"product_name\":\"Amoxi-Denk 1000mg (Box 10Tbl)\",\"quantity\":4,\"message\":\"Amoxi-Denk 1000mg (Box 10Tbl) is low on stock. Only 4 left.\",\"image\":\"1729621234_5368954A-E85D-4713-85AD-C66BFD25097C.jpg\"}',NULL,'2024-12-23 21:19:23','2024-12-23 21:19:23'),('ec88fc0a-4e78-48b6-b5e1-2d3554986c69','App\\Notifications\\LowStockNotification','App\\Models\\User',1,'{\"type\":\"low_stock\",\"product_name\":\"Amoxi-Denk 1000mg (Box 10Tbl)\",\"quantity\":4,\"message\":\"Amoxi-Denk 1000mg (Box 10Tbl) is low on stock. Only 4 left.\",\"image\":\"1729621234_5368954A-E85D-4713-85AD-C66BFD25097C.jpg\"}',NULL,'2024-12-23 21:25:47','2024-12-23 21:25:47'),('50cc2dcb-fbf7-49f6-8fe7-ed335ba95262','App\\Notifications\\LowStockNotification','App\\Models\\User',1,'{\"type\":\"low_stock\",\"product_name\":\"Test Z\",\"quantity\":1,\"message\":\"Test Z is low on stock. Only 1 left.\",\"image\":\"1733160887_860967ea5ec96498be641b75c20edb8e.jpg\"}',NULL,'2024-12-23 21:33:00','2024-12-23 21:33:00'),('f5e10802-33b4-4f86-9f7d-73a1f6267da4','App\\Notifications\\LowStockNotification','App\\Models\\User',1,'{\"type\":\"low_stock\",\"product_name\":\"Test Z\",\"quantity\":4,\"message\":\"Test Z is low on stock. Only 4 left.\",\"image\":\"1733160887_860967ea5ec96498be641b75c20edb8e.jpg\"}',NULL,'2024-12-23 21:44:49','2024-12-23 21:44:49'),('8e115049-d4fc-4f89-ad58-e91259c87c70','App\\Notifications\\LowStockNotification','App\\Models\\User',1,'{\"type\":\"low_stock\",\"product_name\":\"Test Z\",\"quantity\":5,\"message\":\"Test Z is low on stock. Only 5 left.\",\"image\":\"1733160887_860967ea5ec96498be641b75c20edb8e.jpg\"}',NULL,'2024-12-23 21:48:09','2024-12-23 21:48:09'),('3e16ca5c-df0a-4ec1-9475-8f0d1529d271','App\\Notifications\\LowStockNotification','App\\Models\\User',1,'{\"type\":\"low_stock\",\"product_name\":\"Test Z\",\"quantity\":5,\"message\":\"Test Z is low on stock. Only 5 left.\",\"image\":\"1733160887_860967ea5ec96498be641b75c20edb8e.jpg\"}',NULL,'2024-12-23 21:49:05','2024-12-23 21:49:05'),('ad9f8b4b-576a-4922-81a6-47d33624b505','App\\Notifications\\LowStockNotification','App\\Models\\User',1,'{\"type\":\"low_stock\",\"product_name\":\"Test Z\",\"quantity\":5,\"message\":\"Test Z is low on stock. Only 5 left.\",\"image\":\"1733160887_860967ea5ec96498be641b75c20edb8e.jpg\"}',NULL,'2024-12-23 21:52:34','2024-12-23 21:52:34'),('118f8ac3-0ff0-48d0-b091-d128f434609b','App\\Notifications\\LowStockNotification','App\\Models\\User',1,'{\"type\":\"low_stock\",\"product_name\":\"Test Z\",\"quantity\":5,\"message\":\"Test Z is low on stock. Only 5 left.\",\"image\":\"1733160887_860967ea5ec96498be641b75c20edb8e.jpg\"}',NULL,'2024-12-23 21:59:39','2024-12-23 21:59:39'),('a87f0a77-4548-4624-8de3-97a3176f30c4','App\\Notifications\\LowStockNotification','App\\Models\\User',1,'{\"type\":\"low_stock\",\"product_name\":\"Test Z\",\"quantity\":4,\"message\":\"Test Z is low on stock. Only 4 left.\",\"image\":\"1733160887_860967ea5ec96498be641b75c20edb8e.jpg\"}',NULL,'2024-12-23 22:02:04','2024-12-23 22:02:04'),('222b8d26-9750-4f26-8747-fa4e69424ce7','App\\Notifications\\LowStockNotification','App\\Models\\User',1,'{\"type\":\"low_stock\",\"product_name\":\"Amoxi-Denk 1000mg (Box 10Tbl)\",\"quantity\":4,\"message\":\"Amoxi-Denk 1000mg (Box 10Tbl) is low on stock. Only 4 left.\",\"image\":\"1729621234_5368954A-E85D-4713-85AD-C66BFD25097C.jpg\"}',NULL,'2024-12-23 22:16:46','2024-12-23 22:16:46'),('4212f3bd-b394-4089-9ee3-9b7393aa3cc2','App\\Notifications\\LowStockNotification','App\\Models\\User',1,'{\"type\":\"low_stock\",\"product_name\":\"Amoxi-Denk 1000mg (Box 10Tbl)\",\"quantity\":3,\"message\":\"Amoxi-Denk 1000mg (Box 10Tbl) is low on stock. Only 3 left.\",\"image\":\"1729621234_5368954A-E85D-4713-85AD-C66BFD25097C.jpg\"}',NULL,'2024-12-23 22:16:46','2024-12-23 22:16:46'),('34abd564-298d-4c64-949c-feb1ecf7c867','App\\Notifications\\LowStockNotification','App\\Models\\User',1,'{\"type\":\"low_stock\",\"product_name\":\"DOLIPRANE 1000mg 8Comp Effe\\/Box\",\"quantity\":5,\"message\":\"DOLIPRANE 1000mg 8Comp Effe\\/Box is low on stock. Only 5 left.\",\"image\":\"1729615648_C4B96421-8C27-4EA6-91D3-B3E579325920.png\"}',NULL,'2024-12-23 22:16:46','2024-12-23 22:16:46'),('14041acb-180c-4985-8073-322431efe286','App\\Notifications\\LowStockNotification','App\\Models\\User',1,'{\"type\":\"low_stock\",\"product_name\":\"DOLIPRANE 1000mg 8Comp Effe\\/Box\",\"quantity\":5,\"message\":\"DOLIPRANE 1000mg 8Comp Effe\\/Box is low on stock. Only 5 left.\",\"image\":\"1729615648_C4B96421-8C27-4EA6-91D3-B3E579325920.png\"}',NULL,'2024-12-23 22:22:32','2024-12-23 22:22:32'),('7c1335e3-f560-4307-8d88-f77bd62fa7b4','App\\Notifications\\LowStockNotification','App\\Models\\User',1,'{\"type\":\"low_stock\",\"product_name\":\"Amoxi-Denk 1000mg (Box 10Tbl)\",\"quantity\":3,\"message\":\"Amoxi-Denk 1000mg (Box 10Tbl) is low on stock. Only 3 left.\",\"image\":\"1729621234_5368954A-E85D-4713-85AD-C66BFD25097C.jpg\"}',NULL,'2024-12-23 22:22:32','2024-12-23 22:22:32'),('434b8803-ab8b-453d-a617-bef4cc290eaa','App\\Notifications\\LowStockNotification','App\\Models\\User',1,'{\"type\":\"low_stock\",\"product_name\":\"Test Z\",\"quantity\":4,\"message\":\"Test Z is low on stock. Only 4 left.\",\"image\":\"1733160887_860967ea5ec96498be641b75c20edb8e.jpg\"}',NULL,'2024-12-23 22:22:32','2024-12-23 22:22:32'),('914f6d7b-b733-4688-8ea7-e68da6c5c4fb','App\\Notifications\\LowStockNotification','App\\Models\\User',1,'{\"type\":\"low_stock\",\"product_name\":\"Test Z\",\"quantity\":4,\"message\":\"Test Z is low on stock. Only 4 left.\",\"image\":\"1733160887_860967ea5ec96498be641b75c20edb8e.jpg\"}',NULL,'2024-12-23 22:44:49','2024-12-23 22:44:49'),('742faa15-43d9-4a2b-a592-6f6a26b7abd5','App\\Notifications\\LowStockNotification','App\\Models\\User',1,'{\"type\":\"low_stock\",\"product_name\":\"Test Z\",\"quantity\":3,\"message\":\"Test Z is low on stock. Only 3 left.\",\"image\":\"1733160887_860967ea5ec96498be641b75c20edb8e.jpg\"}',NULL,'2024-12-23 22:52:33','2024-12-23 22:52:33'),('f20cd6bf-35a8-4f0c-af1b-1fa5c0e84aa7','App\\Notifications\\LowStockNotification','App\\Models\\User',1,'{\"type\":\"low_stock\",\"product_name\":\"Amoxi-Denk 1000mg (Box 10Tbl)\",\"quantity\":2,\"message\":\"Amoxi-Denk 1000mg (Box 10Tbl) is low on stock. Only 2 left.\",\"image\":\"1729621234_5368954A-E85D-4713-85AD-C66BFD25097C.jpg\"}',NULL,'2024-12-23 23:04:08','2024-12-23 23:04:08'),('7df37745-c1da-4d62-8c70-d31f4ebb2658','App\\Notifications\\LowStockNotification','App\\Models\\User',1,'{\"type\":\"low_stock\",\"product_name\":\"Test Z\",\"quantity\":3,\"message\":\"Test Z is low on stock. Only 3 left.\",\"image\":\"1733160887_860967ea5ec96498be641b75c20edb8e.jpg\"}',NULL,'2024-12-23 23:07:45','2024-12-23 23:07:45'),('7f402a8f-b6ce-4756-879b-489ae889c6a2','App\\Notifications\\LowStockNotification','App\\Models\\User',1,'{\"type\":\"low_stock\",\"product_name\":\"Test Z\",\"quantity\":3,\"message\":\"Test Z is low on stock. Only 3 left.\",\"image\":\"1733160887_860967ea5ec96498be641b75c20edb8e.jpg\"}',NULL,'2024-12-23 23:41:35','2024-12-23 23:41:35'),('d8baca8c-36b1-41f7-806a-3919bd957563','App\\Notifications\\LowStockNotification','App\\Models\\User',1,'{\"type\":\"low_stock\",\"product_name\":\"Amoxi-Denk 1000mg (Box 10Tbl)\",\"quantity\":2,\"message\":\"Amoxi-Denk 1000mg (Box 10Tbl) is low on stock. Only 2 left.\",\"image\":\"1729621234_5368954A-E85D-4713-85AD-C66BFD25097C.jpg\"}',NULL,'2024-12-23 23:41:35','2024-12-23 23:41:35'),('4fc8e3f6-d347-4e96-8f6e-dbc40f3c1d34','App\\Notifications\\LowStockNotification','App\\Models\\User',1,'{\"type\":\"low_stock\",\"product_name\":\"Test Z\",\"quantity\":3,\"message\":\"Test Z is low on stock. Only 3 left.\",\"image\":\"1733160887_860967ea5ec96498be641b75c20edb8e.jpg\"}',NULL,'2024-12-23 23:50:08','2024-12-23 23:50:08'),('cdcc0601-9768-403a-a3a1-29d67c96f87b','App\\Notifications\\LowStockNotification','App\\Models\\User',1,'{\"type\":\"low_stock\",\"product_name\":\"Amoxi-Denk 1000mg (Box 10Tbl)\",\"quantity\":2,\"message\":\"Amoxi-Denk 1000mg (Box 10Tbl) is low on stock. Only 2 left.\",\"image\":\"1729621234_5368954A-E85D-4713-85AD-C66BFD25097C.jpg\"}',NULL,'2024-12-24 08:07:21','2024-12-24 08:07:21'),('87724d44-7e63-456b-897b-93f2b8a1eb16','App\\Notifications\\LowStockNotification','App\\Models\\User',1,'{\"type\":\"low_stock\",\"product_name\":\"Amoklavin-bid 625 mg x 14 film tablets\",\"quantity\":5,\"message\":\"Amoklavin-bid 625 mg x 14 film tablets is low on stock. Only 5 left.\",\"image\":\"1729620475_AMOKLAVIN-625-MG-10-FILM-TAB.png\"}',NULL,'2024-12-24 08:10:16','2024-12-24 08:10:16'),('141d5d9a-5a99-47e8-91e5-e915d0ddbe76','App\\Notifications\\LowStockNotification','App\\Models\\User',1,'{\"type\":\"low_stock\",\"product_name\":\"Amoxi-Denk 1000mg (Box 10Tbl)\",\"quantity\":1,\"message\":\"Amoxi-Denk 1000mg (Box 10Tbl) is low on stock. Only 1 left.\",\"image\":\"1729621234_5368954A-E85D-4713-85AD-C66BFD25097C.jpg\"}',NULL,'2024-12-24 08:10:16','2024-12-24 08:10:16'),('77fa9c1c-6f1b-4a83-98f2-06521641335a','App\\Notifications\\LowStockNotification','App\\Models\\User',1,'{\"type\":\"low_stock\",\"product_name\":\"DOLIPRANE 1000mg 8Comp Effe\\/Box\",\"quantity\":4,\"message\":\"DOLIPRANE 1000mg 8Comp Effe\\/Box is low on stock. Only 4 left.\",\"image\":\"1729615648_C4B96421-8C27-4EA6-91D3-B3E579325920.png\"}',NULL,'2024-12-24 08:36:14','2024-12-24 08:36:14'),('efa0b1d9-1524-4fd3-b111-58d9d7ef1b9e','App\\Notifications\\LowStockNotification','App\\Models\\User',1,'{\"type\":\"low_stock\",\"product_name\":\"Amoklavin-bid 625 mg x 14 film tablets\",\"quantity\":4,\"message\":\"Amoklavin-bid 625 mg x 14 film tablets is low on stock. Only 4 left.\",\"image\":\"1729620475_AMOKLAVIN-625-MG-10-FILM-TAB.png\"}',NULL,'2024-12-24 08:36:14','2024-12-24 08:36:14'),('996c7266-d38f-4a21-b459-50e6aaa3611e','App\\Notifications\\LowStockNotification','App\\Models\\User',1,'{\"type\":\"low_stock\",\"product_name\":\"Amoklavin-bid 625 mg x 14 film tablets\",\"quantity\":3,\"message\":\"Amoklavin-bid 625 mg x 14 film tablets is low on stock. Only 3 left.\",\"image\":\"1729620475_AMOKLAVIN-625-MG-10-FILM-TAB.png\"}',NULL,'2024-12-24 08:49:52','2024-12-24 08:49:52'),('60c63704-191b-4546-b844-743b3b75111e','App\\Notifications\\LowStockNotification','App\\Models\\User',1,'{\"type\":\"low_stock\",\"product_name\":\"DOLIPRANE 1000mg 8Comp Effe\\/Box\",\"quantity\":4,\"message\":\"DOLIPRANE 1000mg 8Comp Effe\\/Box is low on stock. Only 4 left.\",\"image\":\"1729615648_C4B96421-8C27-4EA6-91D3-B3E579325920.png\"}',NULL,'2024-12-24 08:49:52','2024-12-24 08:49:52'),('249639a9-9681-4f85-b743-ae7f240d46e3','App\\Notifications\\LowStockNotification','App\\Models\\User',1,'{\"type\":\"low_stock\",\"product_name\":\"Amoklavin-bid 625 mg x 14 film tablets\",\"quantity\":2,\"message\":\"Amoklavin-bid 625 mg x 14 film tablets is low on stock. Only 2 left.\",\"image\":\"1729620475_AMOKLAVIN-625-MG-10-FILM-TAB.png\"}',NULL,'2024-12-24 08:59:38','2024-12-24 08:59:38'),('3683227c-6bd8-4820-b39a-831d2944efbf','App\\Notifications\\LowStockNotification','App\\Models\\User',1,'{\"type\":\"low_stock\",\"product_name\":\"Amoklavin-bid 625 mg x 14 film tablets\",\"quantity\":2,\"message\":\"Amoklavin-bid 625 mg x 14 film tablets is low on stock. Only 2 left.\",\"image\":\"1729620475_AMOKLAVIN-625-MG-10-FILM-TAB.png\"}',NULL,'2024-12-24 08:59:38','2024-12-24 08:59:38'),('372da009-182c-4827-8be2-3637dfa55c2b','App\\Notifications\\LowStockNotification','App\\Models\\User',1,'{\"type\":\"low_stock\",\"product_name\":\"DOLIPRANE 1000mg 8Comp Effe\\/Box\",\"quantity\":3,\"message\":\"DOLIPRANE 1000mg 8Comp Effe\\/Box is low on stock. Only 3 left.\",\"image\":\"1729615648_C4B96421-8C27-4EA6-91D3-B3E579325920.png\"}',NULL,'2024-12-24 09:05:17','2024-12-24 09:05:17'),('7c97c7e5-e4bb-48ba-8893-fc8b3e900e04','App\\Notifications\\LowStockNotification','App\\Models\\User',1,'{\"type\":\"low_stock\",\"product_name\":\"Amoxi-Denk 1000mg (Box 10Tbl)\",\"quantity\":1,\"message\":\"Amoxi-Denk 1000mg (Box 10Tbl) is low on stock. Only 1 left.\",\"image\":\"1729621234_5368954A-E85D-4713-85AD-C66BFD25097C.jpg\"}',NULL,'2024-12-24 09:05:17','2024-12-24 09:05:17'),('af4d93ba-3a2c-4df9-aee2-12241c0b6dd4','App\\Notifications\\LowStockNotification','App\\Models\\User',1,'{\"type\":\"low_stock\",\"product_name\":\"DOLIPRANE 1000mg 8Comp Effe\\/Box\",\"quantity\":2,\"message\":\"DOLIPRANE 1000mg 8Comp Effe\\/Box is low on stock. Only 2 left.\",\"image\":\"1729615648_C4B96421-8C27-4EA6-91D3-B3E579325920.png\"}',NULL,'2024-12-24 09:23:41','2024-12-24 09:23:41'),('45c8a54e-268b-40c9-a620-06b6385c133b','App\\Notifications\\LowStockNotification','App\\Models\\User',1,'{\"type\":\"low_stock\",\"product_name\":\"DOLIPRANE 1000mg 8Comp Effe\\/Box\",\"quantity\":2,\"message\":\"DOLIPRANE 1000mg 8Comp Effe\\/Box is low on stock. Only 2 left.\",\"image\":\"1729615648_C4B96421-8C27-4EA6-91D3-B3E579325920.png\"}',NULL,'2024-12-24 09:45:14','2024-12-24 09:45:14'),('a1aec358-a9a3-4c2e-b58f-3ebe04050936','App\\Notifications\\LowStockNotification','App\\Models\\User',1,'{\"type\":\"low_stock\",\"product_name\":\"Test Z\",\"quantity\":2,\"message\":\"Test Z is low on stock. Only 2 left.\",\"image\":\"1733160887_860967ea5ec96498be641b75c20edb8e.jpg\"}',NULL,'2024-12-24 09:45:14','2024-12-24 09:45:14'),('24c1c4ef-1eae-4386-971b-21df7c0c01e3','App\\Notifications\\LowStockNotification','App\\Models\\User',1,'{\"type\":\"low_stock\",\"product_name\":\"DOLIPRANE 1000mg 8Comp Effe\\/Box\",\"quantity\":1,\"message\":\"DOLIPRANE 1000mg 8Comp Effe\\/Box is low on stock. Only 1 left.\",\"image\":\"1729615648_C4B96421-8C27-4EA6-91D3-B3E579325920.png\"}',NULL,'2024-12-24 17:54:27','2024-12-24 17:54:27'),('dae7f441-2fd8-4549-8e5b-2daf6489a3a2','App\\Notifications\\LowStockNotification','App\\Models\\User',1,'{\"type\":\"low_stock\",\"product_name\":\"Amoxi-Denk 1000mg (Box 10Tbl)\",\"quantity\":1,\"message\":\"Amoxi-Denk 1000mg (Box 10Tbl) is low on stock. Only 1 left.\",\"image\":\"1729621234_5368954A-E85D-4713-85AD-C66BFD25097C.jpg\"}',NULL,'2024-12-24 17:54:27','2024-12-24 17:54:27');
/*!40000 ALTER TABLE `notifications` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `password_resets`
--

DROP TABLE IF EXISTS `password_resets`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `password_resets` (
  `email` varchar(255) CHARACTER SET utf8mb3 COLLATE utf8mb3_unicode_ci NOT NULL,
  `token` varchar(255) CHARACTER SET utf8mb3 COLLATE utf8mb3_unicode_ci NOT NULL,
  `created_at` timestamp NULL DEFAULT NULL,
  KEY `password_resets_email_index` (`email`)
) ENGINE=MyISAM DEFAULT CHARSET=utf8mb3 COLLATE=utf8mb3_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `password_resets`
--

LOCK TABLES `password_resets` WRITE;
/*!40000 ALTER TABLE `password_resets` DISABLE KEYS */;
INSERT INTO `password_resets` VALUES ('randyssingss@gmail.com','$2y$10$nWGkA3cqp.RLJuoYot8YBOAoia7NPKGWJOOTUUhpOAvAJBOuEM5QS','2024-09-26 08:28:15');
/*!40000 ALTER TABLE `password_resets` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `permissions`
--

DROP TABLE IF EXISTS `permissions`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `permissions` (
  `id` bigint unsigned NOT NULL AUTO_INCREMENT,
  `name` varchar(125) CHARACTER SET utf8mb3 COLLATE utf8mb3_unicode_ci NOT NULL,
  `guard_name` varchar(125) CHARACTER SET utf8mb3 COLLATE utf8mb3_unicode_ci NOT NULL,
  `created_at` timestamp NULL DEFAULT NULL,
  `updated_at` timestamp NULL DEFAULT NULL,
  PRIMARY KEY (`id`),
  UNIQUE KEY `permissions_name_guard_name_unique` (`name`,`guard_name`)
) ENGINE=MyISAM AUTO_INCREMENT=40 DEFAULT CHARSET=utf8mb3 COLLATE=utf8mb3_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `permissions`
--

LOCK TABLES `permissions` WRITE;
/*!40000 ALTER TABLE `permissions` DISABLE KEYS */;
INSERT INTO `permissions` VALUES (1,'view-sales','web',NULL,NULL),(2,'create-sale','web',NULL,NULL),(3,'destroy-sale','web',NULL,NULL),(4,'edit-sale','web',NULL,NULL),(5,'view-reports','web',NULL,NULL),(6,'view-category','web',NULL,NULL),(7,'create-category','web',NULL,NULL),(8,'destroy-category','web',NULL,NULL),(9,'edit-category','web',NULL,NULL),(10,'view-products','web',NULL,NULL),(11,'create-product','web',NULL,NULL),(12,'edit-product','web',NULL,NULL),(13,'destroy-product','web',NULL,NULL),(14,'view-purchase','web',NULL,NULL),(15,'create-purchase','web',NULL,NULL),(16,'edit-purchase','web',NULL,NULL),(17,'destroy-purchase','web',NULL,NULL),(18,'view-supplier','web',NULL,NULL),(19,'create-supplier','web',NULL,NULL),(20,'edit-supplier','web',NULL,NULL),(21,'destroy-supplier','web',NULL,NULL),(22,'view-users','web',NULL,NULL),(23,'create-user','web',NULL,NULL),(24,'edit-user','web',NULL,NULL),(25,'destroy-user','web',NULL,NULL),(26,'view-access-control','web',NULL,NULL),(27,'view-role','web',NULL,NULL),(28,'edit-role','web',NULL,NULL),(29,'destroy-role','web',NULL,NULL),(30,'create-role','web',NULL,NULL),(31,'view-permission','web',NULL,NULL),(32,'create-permission','web',NULL,NULL),(33,'edit-permission','web',NULL,NULL),(34,'destroy-permission','web',NULL,NULL),(35,'view-expired-products','web',NULL,NULL),(36,'view-outstock-products','web',NULL,NULL),(37,'backup-app','web',NULL,NULL),(38,'backup-db','web',NULL,NULL),(39,'view-settings','web',NULL,NULL);
/*!40000 ALTER TABLE `permissions` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `personal_access_tokens`
--

DROP TABLE IF EXISTS `personal_access_tokens`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `personal_access_tokens` (
  `id` bigint unsigned NOT NULL AUTO_INCREMENT,
  `tokenable_type` varchar(255) CHARACTER SET utf8mb3 COLLATE utf8mb3_unicode_ci NOT NULL,
  `tokenable_id` bigint unsigned NOT NULL,
  `name` varchar(255) CHARACTER SET utf8mb3 COLLATE utf8mb3_unicode_ci NOT NULL,
  `token` varchar(64) CHARACTER SET utf8mb3 COLLATE utf8mb3_unicode_ci NOT NULL,
  `abilities` text CHARACTER SET utf8mb3 COLLATE utf8mb3_unicode_ci,
  `last_used_at` timestamp NULL DEFAULT NULL,
  `created_at` timestamp NULL DEFAULT NULL,
  `updated_at` timestamp NULL DEFAULT NULL,
  PRIMARY KEY (`id`),
  UNIQUE KEY `personal_access_tokens_token_unique` (`token`),
  KEY `personal_access_tokens_tokenable_type_tokenable_id_index` (`tokenable_type`,`tokenable_id`)
) ENGINE=MyISAM DEFAULT CHARSET=utf8mb3 COLLATE=utf8mb3_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `personal_access_tokens`
--

LOCK TABLES `personal_access_tokens` WRITE;
/*!40000 ALTER TABLE `personal_access_tokens` DISABLE KEYS */;
/*!40000 ALTER TABLE `personal_access_tokens` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `products`
--

DROP TABLE IF EXISTS `products`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `products` (
  `id` bigint unsigned NOT NULL AUTO_INCREMENT,
  `purchase_id` bigint unsigned DEFAULT NULL,
  `price` decimal(8,2) NOT NULL,
  `discount` decimal(8,2) NOT NULL DEFAULT '0.00',
  `description` text CHARACTER SET utf8mb3 COLLATE utf8mb3_unicode_ci,
  `deleted_at` timestamp NULL DEFAULT NULL,
  `created_at` timestamp NULL DEFAULT NULL,
  `updated_at` timestamp NULL DEFAULT NULL,
  `barcode` varchar(191) CHARACTER SET utf8mb3 COLLATE utf8mb3_unicode_ci DEFAULT NULL,
  PRIMARY KEY (`id`),
  UNIQUE KEY `products_barcode_unique` (`barcode`),
  KEY `products_purchase_id_foreign` (`purchase_id`)
) ENGINE=MyISAM AUTO_INCREMENT=2 DEFAULT CHARSET=utf8mb3 COLLATE=utf8mb3_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `products`
--

LOCK TABLES `products` WRITE;
/*!40000 ALTER TABLE `products` DISABLE KEYS */;
/*!40000 ALTER TABLE `products` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `purchase_details`
--

DROP TABLE IF EXISTS `purchase_details`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `purchase_details` (
  `id` bigint unsigned NOT NULL AUTO_INCREMENT,
  `purchase_id` bigint unsigned NOT NULL,
  `bar_code` varchar(191) CHARACTER SET utf8mb3 COLLATE utf8mb3_unicode_ci DEFAULT NULL,
  `total_purchase_price` decimal(10,2) NOT NULL,
  `created_at` timestamp NULL DEFAULT NULL,
  `updated_at` timestamp NULL DEFAULT NULL,
  `invoice_no` varchar(191) CHARACTER SET utf8mb3 COLLATE utf8mb3_unicode_ci DEFAULT NULL,
  `date` date DEFAULT NULL,
  PRIMARY KEY (`id`),
  KEY `purchase_details_purchase_id_foreign` (`purchase_id`)
) ENGINE=MyISAM AUTO_INCREMENT=13 DEFAULT CHARSET=utf8mb3 COLLATE=utf8mb3_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `purchase_details`
--

LOCK TABLES `purchase_details` WRITE;
/*!40000 ALTER TABLE `purchase_details` DISABLE KEYS */;
INSERT INTO `purchase_details` VALUES (1,6,'3582910075820',8.80,'2024-12-22 22:29:09','2024-12-22 22:29:09','12837129873891','2024-12-23'),(2,4,'8699525093172',49.52,'2024-12-22 23:33:07','2024-12-22 23:33:07','12`112','2024-12-23'),(3,5,'12345',50.00,'2024-12-22 23:44:34','2024-12-22 23:44:34','2312312321','2024-12-23'),(4,6,'3582910075820',15.40,'2024-12-22 23:50:51','2024-12-22 23:50:51','223123','2024-12-23'),(5,7,'8699525093172',99.04,'2024-12-22 23:59:19','2024-12-22 23:59:19','231251251','2024-12-23'),(6,8,NULL,32.20,'2024-12-23 00:02:58','2024-12-23 00:02:58','512511','2024-12-23'),(7,9,NULL,90.00,'2024-12-23 00:15:39','2024-12-23 00:15:39','2512512515','2024-12-23'),(8,10,NULL,72.00,'2024-12-23 03:08:14','2024-12-23 03:08:14','51214123','2024-12-23'),(9,11,NULL,100.00,'2024-12-23 11:40:47','2024-12-23 11:40:47','21251213','2024-12-23'),(10,12,NULL,80.00,'2024-12-24 09:44:26','2024-12-24 09:44:26','234567890','2024-12-24'),(11,13,NULL,160.00,'2024-12-24 09:44:26','2024-12-24 09:44:26','234567890','2024-12-24'),(12,14,NULL,100.00,'2024-12-24 09:44:26','2024-12-24 09:44:26','234567890','2024-12-24');
/*!40000 ALTER TABLE `purchase_details` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `purchase_sales`
--

DROP TABLE IF EXISTS `purchase_sales`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `purchase_sales` (
  `id` bigint unsigned NOT NULL AUTO_INCREMENT,
  `sale_id` bigint unsigned NOT NULL,
  `purchase_id` bigint unsigned NOT NULL,
  `quantity` int NOT NULL,
  `created_at` timestamp NULL DEFAULT NULL,
  `updated_at` timestamp NULL DEFAULT NULL,
  PRIMARY KEY (`id`),
  KEY `purchase_sales_sale_id_foreign` (`sale_id`),
  KEY `purchase_sales_purchase_id_foreign` (`purchase_id`)
) ENGINE=MyISAM AUTO_INCREMENT=69 DEFAULT CHARSET=utf8mb3 COLLATE=utf8mb3_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `purchase_sales`
--

LOCK TABLES `purchase_sales` WRITE;
/*!40000 ALTER TABLE `purchase_sales` DISABLE KEYS */;
INSERT INTO `purchase_sales` VALUES (1,1,10,1,'2024-12-23 03:12:24','2024-12-23 03:12:24'),(2,2,10,2,'2024-12-23 03:13:14','2024-12-23 03:13:14'),(3,3,9,1,'2024-12-23 03:16:54','2024-12-23 03:16:54'),(4,4,9,1,'2024-12-23 03:20:57','2024-12-23 03:20:57'),(5,5,4,1,'2024-12-23 03:21:31','2024-12-23 03:21:31'),(6,6,4,1,'2024-12-23 03:21:42','2024-12-23 03:21:42'),(7,7,10,1,'2024-12-23 11:58:15','2024-12-23 11:58:15'),(8,8,10,31,'2024-12-23 12:00:11','2024-12-23 12:00:11'),(9,9,11,1,'2024-12-23 12:08:23','2024-12-23 12:08:23'),(10,10,11,2,'2024-12-23 12:09:13','2024-12-23 12:09:13'),(11,11,11,1,'2024-12-23 12:16:55','2024-12-23 12:16:55'),(12,12,10,1,'2024-12-23 12:20:14','2024-12-23 12:20:14'),(13,13,10,1,'2024-12-23 12:23:23','2024-12-23 12:23:23'),(14,14,10,1,'2024-12-23 12:23:55','2024-12-23 12:23:55'),(15,15,8,1,'2024-12-23 12:28:37','2024-12-23 12:28:37'),(16,16,10,1,'2024-12-23 12:37:35','2024-12-23 12:37:35'),(17,17,8,1,'2024-12-23 12:41:46','2024-12-23 12:41:46'),(30,30,5,1,'2024-12-23 21:56:44','2024-12-23 21:56:44'),(31,31,5,1,'2024-12-23 21:59:39','2024-12-23 21:59:39'),(32,32,5,1,'2024-12-23 22:02:04','2024-12-23 22:02:04'),(21,21,8,10,'2024-12-23 21:00:50','2024-12-23 21:00:50'),(22,22,7,1,'2024-12-23 21:06:41','2024-12-23 21:06:41'),(33,33,8,1,'2024-12-23 22:16:46','2024-12-23 22:16:46'),(24,24,8,1,'2024-12-23 21:19:23','2024-12-23 21:19:23'),(25,25,8,1,'2024-12-23 21:25:47','2024-12-23 21:25:47'),(34,34,8,1,'2024-12-23 22:16:46','2024-12-23 22:16:46'),(35,35,6,1,'2024-12-23 22:16:46','2024-12-23 22:16:46'),(36,36,6,4,'2024-12-23 22:16:46','2024-12-23 22:16:46'),(37,1,6,1,'2024-12-23 22:22:32','2024-12-23 22:22:32'),(38,2,7,1,'2024-12-23 22:22:32','2024-12-23 22:22:32'),(39,3,8,1,'2024-12-23 22:22:32','2024-12-23 22:22:32'),(40,4,5,1,'2024-12-23 22:22:32','2024-12-23 22:22:32'),(41,5,5,1,'2024-12-23 22:44:49','2024-12-23 22:44:49'),(42,6,7,1,'2024-12-23 22:44:49','2024-12-23 22:44:49'),(43,7,5,1,'2024-12-23 22:52:33','2024-12-23 22:52:33'),(44,8,8,1,'2024-12-23 23:04:08','2024-12-23 23:04:08'),(45,9,5,1,'2024-12-23 23:07:45','2024-12-23 23:07:45'),(46,10,5,4,'2024-12-23 23:41:35','2024-12-23 23:41:35'),(47,11,8,1,'2024-12-23 23:41:35','2024-12-23 23:41:35'),(48,12,5,1,'2024-12-23 23:50:08','2024-12-23 23:50:08'),(49,1,8,4,'2024-12-24 08:07:21','2024-12-24 08:07:21'),(50,2,7,1,'2024-12-24 08:07:21','2024-12-24 08:07:21'),(51,1,7,1,'2024-12-24 08:10:16','2024-12-24 08:10:16'),(52,2,8,1,'2024-12-24 08:10:16','2024-12-24 08:10:16'),(53,3,6,5,'2024-12-24 08:36:14','2024-12-24 08:36:14'),(54,4,7,1,'2024-12-24 08:36:14','2024-12-24 08:36:14'),(55,5,7,1,'2024-12-24 08:49:52','2024-12-24 08:49:52'),(56,6,6,1,'2024-12-24 08:49:52','2024-12-24 08:49:52'),(57,7,7,1,'2024-12-24 08:59:38','2024-12-24 08:59:38'),(58,8,7,1,'2024-12-24 08:59:38','2024-12-24 08:59:38'),(59,1,6,1,'2024-12-24 09:05:17','2024-12-24 09:05:17'),(60,2,8,1,'2024-12-24 09:05:17','2024-12-24 09:05:17'),(61,3,6,1,'2024-12-24 09:23:41','2024-12-24 09:23:41'),(62,4,12,3,'2024-12-24 09:45:14','2024-12-24 09:45:14'),(63,5,13,3,'2024-12-24 09:45:14','2024-12-24 09:45:14'),(64,6,14,2,'2024-12-24 09:45:14','2024-12-24 09:45:14'),(65,7,6,5,'2024-12-24 09:45:14','2024-12-24 09:45:14'),(66,8,5,1,'2024-12-24 09:45:14','2024-12-24 09:45:14'),(67,9,6,1,'2024-12-24 17:54:27','2024-12-24 17:54:27'),(68,10,8,5,'2024-12-24 17:54:27','2024-12-24 17:54:27');
/*!40000 ALTER TABLE `purchase_sales` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `purchases`
--

DROP TABLE IF EXISTS `purchases`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `purchases` (
  `id` bigint unsigned NOT NULL AUTO_INCREMENT,
  `bar_code_id` bigint unsigned DEFAULT NULL,
  `category_id` bigint unsigned DEFAULT NULL,
  `supplier_id` bigint unsigned DEFAULT NULL,
  `cost_price` decimal(8,2) DEFAULT NULL,
  `quantity` varchar(191) CHARACTER SET utf8mb3 COLLATE utf8mb3_unicode_ci NOT NULL,
  `original_quantity` int DEFAULT NULL,
  `expiry_date` varchar(191) CHARACTER SET utf8mb3 COLLATE utf8mb3_unicode_ci DEFAULT NULL,
  `near_expiry_date` date DEFAULT NULL,
  `image` varchar(191) CHARACTER SET utf8mb3 COLLATE utf8mb3_unicode_ci DEFAULT NULL,
  `pill_amount` int DEFAULT '0',
  `leftover_pills` int DEFAULT '0',
  `original_pill_amount` int DEFAULT '0',
  `created_at` timestamp NULL DEFAULT NULL,
  `updated_at` timestamp NULL DEFAULT NULL,
  PRIMARY KEY (`id`),
  KEY `purchases_category_id_foreign` (`category_id`),
  KEY `purchases_supplier_id_foreign` (`supplier_id`),
  KEY `purchases_bar_code_id_foreign` (`bar_code_id`)
) ENGINE=MyISAM AUTO_INCREMENT=15 DEFAULT CHARSET=utf8mb3 COLLATE=utf8mb3_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `purchases`
--

LOCK TABLES `purchases` WRITE;
/*!40000 ALTER TABLE `purchases` DISABLE KEYS */;
INSERT INTO `purchases` VALUES (4,6,2,2,12.38,'2',4,'2024-12-11',NULL,'1729620475_AMOKLAVIN-625-MG-10-FILM-TAB.png',14,13,14,'2024-12-22 23:33:07','2024-12-23 03:21:42'),(5,17,2,1,10.00,'2',5,'2024-12-29',NULL,'1733160887_860967ea5ec96498be641b75c20edb8e.jpg',24,9,24,'2024-12-22 23:44:34','2024-12-24 09:45:14'),(6,4,2,1,2.20,'1',7,'2024-12-29',NULL,'1729615648_C4B96421-8C27-4EA6-91D3-B3E579325920.png',8,0,8,'2024-12-22 23:50:51','2024-12-24 17:54:27'),(7,6,2,2,12.38,'0',8,'2024-12-29',NULL,'1729620475_AMOKLAVIN-625-MG-10-FILM-TAB.png',14,12,14,'2024-12-22 23:59:19','2024-12-24 08:59:38'),(8,8,2,2,4.60,'1',7,'2024-12-30','2024-12-23','1729621234_5368954A-E85D-4713-85AD-C66BFD25097C.jpg',10,3,10,'2024-12-23 00:02:58','2024-12-24 17:54:27'),(9,9,2,2,9.00,'9',10,'2024-12-22','2024-12-15','1729621332_16231208224036941_720x@2x.png',30,28,30,'2024-12-23 00:15:39','2024-12-23 03:20:57'),(10,9,2,2,9.00,'0',8,'2025-02-28','2025-02-21','1729621332_16231208224036941_720x@2x.png',30,28,30,'2024-12-23 03:08:14','2024-12-23 12:37:35'),(11,25,2,2,20.00,'0',5,'2025-05-01','2025-04-24','1734670584_81QjqQCZx4L.jpg',100,0,100,'2024-12-23 11:40:47','2024-12-23 12:16:55'),(12,18,3,3,8.00,'7',10,'2025-05-30','2025-05-23','1733749586_thumb-7L2U7Iqk7JWM7JeR7Iqk7Yag64SI7JeQ7IS87Iqk_405x405.jpg',0,0,0,'2024-12-24 09:44:26','2024-12-24 09:45:14'),(13,20,3,3,16.00,'7',10,'2025-05-02','2025-04-25','1733750092_thumb-anua_toner_405x405.jpg',0,0,0,'2024-12-24 09:44:26','2024-12-24 09:45:14'),(14,21,3,3,10.00,'8',10,'2025-05-10','2025-05-03','1733750468_7Yag7L2U67O07ISg7Iqk7Yux5.jpg',0,0,0,'2024-12-24 09:44:26','2024-12-24 09:45:14');
/*!40000 ALTER TABLE `purchases` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `receipts`
--

DROP TABLE IF EXISTS `receipts`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `receipts` (
  `id` bigint unsigned NOT NULL AUTO_INCREMENT,
  `invoice_id` varchar(50) NOT NULL,
  `sale_id` bigint unsigned NOT NULL,
  `date` datetime NOT NULL,
  `total_amount` decimal(10,2) NOT NULL,
  `receipt_details` text NOT NULL,
  `created_at` timestamp NULL DEFAULT NULL,
  `updated_at` timestamp NULL DEFAULT NULL,
  PRIMARY KEY (`id`),
  KEY `sale_id` (`sale_id`)
) ENGINE=MyISAM AUTO_INCREMENT=5 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `receipts`
--

LOCK TABLES `receipts` WRITE;
/*!40000 ALTER TABLE `receipts` DISABLE KEYS */;
INSERT INTO `receipts` VALUES (1,'INV-676ADBBD284BF',2,'2024-12-24 16:05:17',3.66,'All items for this invoice','2024-12-24 09:05:17','2024-12-24 09:05:17'),(2,'INV-676AE00D44ABC',3,'2024-12-24 16:23:41',3.20,'All items for this invoice','2024-12-24 09:23:41','2024-12-24 09:23:41'),(3,'INV-676AE51A4A652',8,'2024-12-24 16:45:14',137.40,'All items for this invoice','2024-12-24 09:45:14','2024-12-24 09:45:14'),(4,'INV-676B57C35EA45',10,'2024-12-25 00:54:27',5.50,'All items for this invoice','2024-12-24 17:54:27','2024-12-24 17:54:27');
/*!40000 ALTER TABLE `receipts` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `role_has_permissions`
--

DROP TABLE IF EXISTS `role_has_permissions`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `role_has_permissions` (
  `permission_id` bigint unsigned NOT NULL,
  `role_id` bigint unsigned NOT NULL,
  PRIMARY KEY (`permission_id`,`role_id`),
  KEY `role_has_permissions_role_id_foreign` (`role_id`)
) ENGINE=MyISAM DEFAULT CHARSET=utf8mb3 COLLATE=utf8mb3_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `role_has_permissions`
--

LOCK TABLES `role_has_permissions` WRITE;
/*!40000 ALTER TABLE `role_has_permissions` DISABLE KEYS */;
INSERT INTO `role_has_permissions` VALUES (1,1),(1,2),(2,1),(2,2),(3,2),(4,2),(5,1),(5,2),(6,2),(7,2),(8,2),(9,2),(10,2),(11,2),(12,2),(13,2),(14,2),(15,2),(16,2),(17,2),(18,2),(19,2),(20,2),(21,2),(22,2),(23,2),(24,2),(25,2),(26,2),(27,2),(28,2),(29,2),(30,2),(31,2),(32,2),(33,2),(34,2),(35,2),(36,2),(37,2),(38,2),(39,2);
/*!40000 ALTER TABLE `role_has_permissions` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `roles`
--

DROP TABLE IF EXISTS `roles`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `roles` (
  `id` bigint unsigned NOT NULL AUTO_INCREMENT,
  `name` varchar(125) CHARACTER SET utf8mb3 COLLATE utf8mb3_unicode_ci NOT NULL,
  `guard_name` varchar(125) CHARACTER SET utf8mb3 COLLATE utf8mb3_unicode_ci NOT NULL,
  `created_at` timestamp NULL DEFAULT NULL,
  `updated_at` timestamp NULL DEFAULT NULL,
  PRIMARY KEY (`id`),
  UNIQUE KEY `roles_name_guard_name_unique` (`name`,`guard_name`)
) ENGINE=MyISAM AUTO_INCREMENT=3 DEFAULT CHARSET=utf8mb3 COLLATE=utf8mb3_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `roles`
--

LOCK TABLES `roles` WRITE;
/*!40000 ALTER TABLE `roles` DISABLE KEYS */;
INSERT INTO `roles` VALUES (1,'sales-person','web','2024-09-26 06:30:04','2024-09-26 06:30:04'),(2,'super-admin','web','2024-09-26 06:30:04','2024-09-26 06:30:04');
/*!40000 ALTER TABLE `roles` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `sales`
--

DROP TABLE IF EXISTS `sales`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `sales` (
  `id` bigint unsigned NOT NULL AUTO_INCREMENT,
  `invoice_id` varchar(50) COLLATE utf8mb3_unicode_ci NOT NULL,
  `purchase_id` bigint unsigned DEFAULT NULL,
  `bar_code_id` bigint unsigned DEFAULT NULL,
  `quantity` int NOT NULL,
  `total_price` decimal(8,2) NOT NULL,
  `deleted_at` timestamp NULL DEFAULT NULL,
  `created_at` timestamp NULL DEFAULT NULL,
  `updated_at` timestamp NULL DEFAULT NULL,
  `discount_type` varchar(50) CHARACTER SET utf8mb3 COLLATE utf8mb3_unicode_ci DEFAULT NULL,
  `discount_value` decimal(10,2) DEFAULT '0.00',
  `payment_method` varchar(50) CHARACTER SET utf8mb3 COLLATE utf8mb3_unicode_ci DEFAULT 'cash',
  `pay_amount_dollar` decimal(10,2) DEFAULT '0.00',
  `pay_amount_riel` decimal(10,2) DEFAULT '0.00',
  `due_amount_dollar` decimal(10,2) DEFAULT '0.00',
  `due_amount_riel` decimal(10,2) DEFAULT '0.00',
  `cashback_dollar` decimal(10,2) DEFAULT '0.00',
  `cashback_riel` decimal(10,2) DEFAULT '0.00',
  `sale_by` varchar(50) COLLATE utf8mb3_unicode_ci DEFAULT NULL,
  PRIMARY KEY (`id`),
  KEY `sales_bar_code_id_foreign` (`bar_code_id`)
) ENGINE=MyISAM AUTO_INCREMENT=11 DEFAULT CHARSET=utf8mb3 COLLATE=utf8mb3_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `sales`
--

LOCK TABLES `sales` WRITE;
/*!40000 ALTER TABLE `sales` DISABLE KEYS */;
INSERT INTO `sales` VALUES (1,'INV-676ADBBD284BF',NULL,4,1,3.20,NULL,'2024-12-24 09:05:17','2024-12-24 09:05:17','percentage',2.00,'cash',5.00,20000.00,1.41,5653.00,0.00,0.00,'box'),(2,'INV-676ADBBD284BF',NULL,8,1,0.46,NULL,'2024-12-24 09:05:17','2024-12-24 09:05:17','percentage',2.00,'cash',5.00,20000.00,1.41,5653.00,0.00,0.00,'pill'),(3,'INV-676AE00D44ABC',NULL,4,1,3.20,NULL,'2024-12-24 09:23:41','2024-12-24 09:23:41','fixed-dollar',1.00,'cash',3.00,12000.00,0.80,3200.00,0.00,0.00,'box'),(4,'INV-676AE51A4A652',NULL,18,3,36.00,NULL,'2024-12-24 09:45:14','2024-12-24 09:45:14','percentage',0.00,'cash',137.40,549600.00,0.00,0.00,0.00,0.00,'box'),(5,'INV-676AE51A4A652',NULL,20,3,60.00,NULL,'2024-12-24 09:45:14','2024-12-24 09:45:14','percentage',0.00,'cash',137.40,549600.00,0.00,0.00,0.00,0.00,'box'),(6,'INV-676AE51A4A652',NULL,21,2,28.00,NULL,'2024-12-24 09:45:14','2024-12-24 09:45:14','percentage',0.00,'cash',137.40,549600.00,0.00,0.00,0.00,0.00,'box'),(7,'INV-676AE51A4A652',NULL,4,5,1.40,NULL,'2024-12-24 09:45:14','2024-12-24 09:45:14','percentage',0.00,'cash',137.40,549600.00,0.00,0.00,0.00,0.00,'pill'),(8,'INV-676AE51A4A652',NULL,17,1,12.00,NULL,'2024-12-24 09:45:14','2024-12-24 09:45:14','percentage',0.00,'cash',137.40,549600.00,0.00,0.00,0.00,0.00,'box'),(9,'INV-676B57C35EA45',NULL,4,1,3.20,NULL,'2024-12-24 17:54:27','2024-12-24 17:54:27','fixed-riel',2000.00,'cash',12.50,50000.00,7.50,30000.00,0.00,0.00,'box'),(10,'INV-676B57C35EA45',NULL,8,5,2.30,NULL,'2024-12-24 17:54:27','2024-12-24 17:54:27','fixed-riel',2000.00,'cash',12.50,50000.00,7.50,30000.00,0.00,0.00,'pill');
/*!40000 ALTER TABLE `sales` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `sales_backup`
--

DROP TABLE IF EXISTS `sales_backup`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `sales_backup` (
  `id` bigint unsigned NOT NULL DEFAULT '0',
  `purchase_id` bigint unsigned DEFAULT NULL,
  `product_id` bigint unsigned DEFAULT NULL,
  `quantity` int NOT NULL,
  `total_price` decimal(8,2) NOT NULL,
  `deleted_at` timestamp NULL DEFAULT NULL,
  `created_at` timestamp NULL DEFAULT NULL,
  `updated_at` timestamp NULL DEFAULT NULL
) ENGINE=MyISAM DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `sales_backup`
--

LOCK TABLES `sales_backup` WRITE;
/*!40000 ALTER TABLE `sales_backup` DISABLE KEYS */;
INSERT INTO `sales_backup` VALUES (1,NULL,NULL,1,12.00,NULL,'2024-12-19 08:09:53','2024-12-19 08:09:53'),(2,NULL,NULL,1,0.42,NULL,'2024-12-19 08:09:53','2024-12-19 08:09:53'),(3,NULL,NULL,1,12.00,NULL,'2024-12-19 08:09:53','2024-12-19 08:09:53'),(4,NULL,NULL,4,1.68,NULL,'2024-12-19 08:11:31','2024-12-19 08:11:31');
/*!40000 ALTER TABLE `sales_backup` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `settings`
--

DROP TABLE IF EXISTS `settings`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `settings` (
  `id` int unsigned NOT NULL AUTO_INCREMENT,
  `name` varchar(255) CHARACTER SET utf8mb3 COLLATE utf8mb3_unicode_ci NOT NULL,
  `val` text CHARACTER SET utf8mb3 COLLATE utf8mb3_unicode_ci,
  `group` varchar(255) CHARACTER SET utf8mb3 COLLATE utf8mb3_unicode_ci NOT NULL DEFAULT 'default',
  `created_at` timestamp NULL DEFAULT NULL,
  `updated_at` timestamp NULL DEFAULT NULL,
  PRIMARY KEY (`id`)
) ENGINE=MyISAM DEFAULT CHARSET=utf8mb3 COLLATE=utf8mb3_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `settings`
--

LOCK TABLES `settings` WRITE;
/*!40000 ALTER TABLE `settings` DISABLE KEYS */;
/*!40000 ALTER TABLE `settings` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `suppliers`
--

DROP TABLE IF EXISTS `suppliers`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `suppliers` (
  `id` bigint unsigned NOT NULL AUTO_INCREMENT,
  `name` varchar(191) CHARACTER SET utf8mb3 COLLATE utf8mb3_unicode_ci NOT NULL,
  `email` varchar(191) CHARACTER SET utf8mb3 COLLATE utf8mb3_unicode_ci DEFAULT NULL,
  `phone` varchar(191) CHARACTER SET utf8mb3 COLLATE utf8mb3_unicode_ci DEFAULT NULL,
  `company` varchar(191) CHARACTER SET utf8mb3 COLLATE utf8mb3_unicode_ci DEFAULT NULL,
  `address` varchar(191) CHARACTER SET utf8mb3 COLLATE utf8mb3_unicode_ci DEFAULT NULL,
  `product` varchar(191) CHARACTER SET utf8mb3 COLLATE utf8mb3_unicode_ci DEFAULT NULL,
  `comment` text CHARACTER SET utf8mb3 COLLATE utf8mb3_unicode_ci,
  `created_at` timestamp NULL DEFAULT NULL,
  `updated_at` timestamp NULL DEFAULT NULL,
  PRIMARY KEY (`id`)
) ENGINE=MyISAM AUTO_INCREMENT=4 DEFAULT CHARSET=utf8mb3 COLLATE=utf8mb3_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `suppliers`
--

LOCK TABLES `suppliers` WRITE;
/*!40000 ALTER TABLE `suppliers` DISABLE KEYS */;
INSERT INTO `suppliers` VALUES (1,'Supplier A','randy@gmail.com','017312312',NULL,'Phsar Olympic',NULL,NULL,'2024-10-13 01:27:09','2024-10-13 01:37:26'),(2,'Depo Doctor Porhea',NULL,NULL,NULL,NULL,NULL,NULL,'2024-10-22 11:11:05','2024-10-22 11:11:05'),(3,'StyleKorean',NULL,NULL,NULL,NULL,NULL,NULL,'2024-12-09 06:05:14','2024-12-09 06:05:14');
/*!40000 ALTER TABLE `suppliers` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `users`
--

DROP TABLE IF EXISTS `users`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `users` (
  `id` bigint unsigned NOT NULL AUTO_INCREMENT,
  `name` varchar(255) CHARACTER SET utf8mb3 COLLATE utf8mb3_unicode_ci NOT NULL,
  `email` varchar(255) CHARACTER SET utf8mb3 COLLATE utf8mb3_unicode_ci NOT NULL,
  `email_verified_at` timestamp NULL DEFAULT NULL,
  `password` varchar(255) CHARACTER SET utf8mb3 COLLATE utf8mb3_unicode_ci NOT NULL,
  `remember_token` varchar(100) CHARACTER SET utf8mb3 COLLATE utf8mb3_unicode_ci DEFAULT NULL,
  `created_at` timestamp NULL DEFAULT NULL,
  `updated_at` timestamp NULL DEFAULT NULL,
  `avatar` varchar(191) CHARACTER SET utf8mb3 COLLATE utf8mb3_unicode_ci DEFAULT NULL,
  PRIMARY KEY (`id`),
  UNIQUE KEY `users_email_unique` (`email`)
) ENGINE=MyISAM AUTO_INCREMENT=4 DEFAULT CHARSET=utf8mb3 COLLATE=utf8mb3_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `users`
--

LOCK TABLES `users` WRITE;
/*!40000 ALTER TABLE `users` DISABLE KEYS */;
INSERT INTO `users` VALUES (1,'Porchhing','admin@mail.com',NULL,'$2y$10$TFc1wGhy5G324BoSO/ZiO.e.6vZHRUz0aeClbXG.4A0cHtXi/tXkq',NULL,'2024-09-26 06:30:05','2024-10-13 00:53:14',NULL),(2,'Va Porhea','vaporhea@gmail.com',NULL,'$2y$10$rKvbq3fsO3S3uIQM6RdZHeBNFUVofU9SZ/sh.ewzA5fVaCwsnOj.6',NULL,'2024-09-26 08:14:22','2024-09-26 08:17:01','1727363821.png'),(3,'Randy San','randyssingss@gmail.com',NULL,'$2y$10$xcqh335B2VzpNEkdDFPcK.p9WrkJjNYNXZagJ35781pE3YNe5P0mm',NULL,'2024-09-26 08:28:04','2024-09-26 08:28:04',NULL);
/*!40000 ALTER TABLE `users` ENABLE KEYS */;
UNLOCK TABLES;
/*!40103 SET TIME_ZONE=@OLD_TIME_ZONE */;

/*!40101 SET SQL_MODE=@OLD_SQL_MODE */;
/*!40014 SET FOREIGN_KEY_CHECKS=@OLD_FOREIGN_KEY_CHECKS */;
/*!40014 SET UNIQUE_CHECKS=@OLD_UNIQUE_CHECKS */;
/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
/*!40111 SET SQL_NOTES=@OLD_SQL_NOTES */;

-- Dump completed on 2024-12-25  8:01:00
